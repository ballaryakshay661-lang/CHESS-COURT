# PLAYHUB API

The Express API is served by the same process as the frontend. The default local base URL is `http://localhost:5000/api`. JSON request bodies use `Content-Type: application/json`.

## Status and public data

| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/health` | None | Pings MongoDB; returns 200 when connected, otherwise 503 with `database: "disconnected"`. |
| GET | `/pricing` | None | Returns configured public badminton, chess, and chess-pass prices. |
| GET | `/settings` | None | Current persisted business settings. |
| GET | `/availability?date=YYYY-MM-DD&activity=Badminton\|Chess` | None | Per-hour capacity and occupancy. Requires MongoDB. |
| POST | `/contact` | None | Persists `{ "name", "email", "message" }`. |
| GET | `/activities` | None | Lists community activities without participant IDs. |

## Customer authentication

Register with `POST /auth/register`:

```json
{
  "name": "Customer Name",
  "mobile": "9876543210",
  "password": "a-private-password"
}
```

Login with `POST /auth/login` using `{ "mobile", "password" }`. Successful responses include a customer JWT. Send it as `Authorization: Bearer <customerToken>` on customer-only endpoints. `GET /auth/me` returns the authenticated profile.

## Customer bookings and rewards

| Method | Path | Auth | Notes |
|---|---|---|---|
| POST | `/bookings` | Customer | Creates a pending advance booking and reserves the resource before returning 201. Body: `customerName`, `activity`, `date`, `startTime`, `duration`, optional `players`/`message`. Customer ID and mobile come from the authenticated account. |
| GET | `/bookings/my` | Customer | Lists only the caller's bookings. |
| GET | `/bookings/:reference` | Customer | Returns a booking only if owned by the caller. |
| POST | `/bookings/:reference/cancel` | Customer | Requests cancellation; body may include `reason`. |
| POST | `/bookings/:reference/reschedule` | Customer | Requests a replacement date/time/duration; replacement capacity is reserved before the request succeeds. |
| GET | `/loyalty/me` | Customer | Returns separate badminton/chess balances. |
| POST | `/loyalty/redeem` | Customer | Secures a one-hour reward booking when the activity balance has at least four credits. Body: `activity`, `date`, `startTime`. |

Booking activity is `Badminton` or `Chess`; dates must be current/future `YYYY-MM-DD`; start times use 15-minute increments within venue hours; duration is 1–6 whole hours. The server calculates the price and ignores client-supplied identity/pricing fields. Slot conflicts return 409.

## Community and chess passes

| Method | Path | Auth | Notes |
|---|---|---|---|
| POST | `/activities` | Customer | Creates a player activity with activity, title, date, time, duration, format, and available slots. |
| POST | `/activities/:activityId/join` | Customer | Atomically joins an open activity with remaining capacity; duplicate/full requests return 409. |
| POST | `/waitlist` | Customer | Adds `{ "activity", "date", "time" }`; duplicate membership returns 409. |
| GET | `/waitlist/my` | Customer | Lists the caller's waitlist entries. |
| POST | `/chess-passes` | Customer | Requests a pass with `customerName`, `startDate`, and optional message; account mobile/owner are server-bound. |
| GET | `/chess-passes/my` | Customer | Lists the caller's pass requests. |

Waitlist acceptance/offers and automatic chess-pass expiry/renewal are not implemented.

## Admin authentication and operations

Admin login: `POST /admin/login` with `{ "username", "password" }`. Credentials are provisioned from server environment configuration; there is no public admin registration. Use its token as `Authorization: Bearer <adminToken>` for all other admin endpoints.

| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/admin/dashboard` | Admin | Database-backed dashboard summary. |
| GET | `/admin/bookings` | Admin | Lists bookings. |
| POST | `/admin/bookings/spot` | Admin | Creates a secured walk-in booking. Body includes customer name/mobile, activity, date, start time, duration, and optional player count. |
| PATCH | `/admin/bookings/:id/status` | Admin | Updates booking lifecycle status; allowed values are validated by the server. Completion requires a paid payment record. |
| GET | `/admin/bookings/:id/payments` | Admin | Lists payment records. |
| POST | `/admin/bookings/:id/payments` | Admin | Records a `Cash` or `UPI` payment with a separate status (`Pending`, `Paid`, `Failed`, `Refunded`). A paid UPI record requires `transactionReference`. |
| GET | `/admin/chess-passes` | Admin | Lists pass requests. |
| PATCH | `/admin/chess-passes/:id/status` | Admin | Updates pass status to `Active`, `Rejected`, or `Expired`. |

## Errors and operational behavior

Errors are JSON, generally `{ "message": "..." }`; database unavailability is HTTP 503 with code `DATABASE_UNAVAILABLE`, and slot conflicts are HTTP 409. Authentication failures are 401; role failures are 403. API requests are rate limited.

Reservations use unique MongoDB resource/time cells and rollback/reconciliation, not multi-document transactions. The configured standalone MongoDB topology does not support transactions. A replica set is required before implementing transaction-based reservation writes. See [PROJECT_AUDIT.md](./PROJECT_AUDIT.md) for verified limitations and outstanding product scope.

## Postman

Import `postman/playhub.postman_collection.json` and `postman/PLAYHUB Local.postman_environment.json`. Select the `PLAYHUB Local` environment, set private credentials there, run customer/admin login requests, then run their protected requests. The health request includes a Postman test that expects MongoDB-connected status. Keep populated tokens and credentials out of exported files and source control.
