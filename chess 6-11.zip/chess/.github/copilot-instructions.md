# PLAYHUB Copilot Instructions

## Project preservation and stack

- Preserve the existing PLAYHUB architecture and folder structure. Never rebuild the project from scratch or replace working code unnecessarily.
- Use the existing stack: HTML5, CSS3, Vanilla JavaScript, Node.js, Express.js, MongoDB, and Mongoose.
- Do not introduce React, Next.js, TypeScript, Tailwind, Bootstrap, Firebase, Supabase, MySQL, or PostgreSQL.
- Keep frontend CSS in `frontend/css/`, frontend JavaScript in `frontend/javascript/`, and backend JavaScript in `backend/javascript/`.

## Focused file reading

- Begin with the exact files mentioned in the prompt.
- Read only files directly relevant to the requested task. Inspect related routes, controllers, models, services, and tests only when necessary.
- Avoid full-workspace searches for small changes. Do not repeatedly read files already inspected unless they changed or need verification.
- Do not scan `node_modules`, `.git`, build output, generated files, logs, or uploads.
- Do not inspect every project file unless explicitly asked for a complete audit.
- Avoid `#codebase` or equivalent full-project context for small tasks unless necessary.
- Do not assume every file needs to be read before making a change.

## Development safety

- Make the smallest safe change and reuse existing functions, APIs, models, and components.
- Maintain existing functionality and compatibility.
- Do not delete features, tests, configuration, or documentation without authorization.
- Never expose `.env` secrets.
- Ask before making unrelated architectural changes.
- Run relevant tests rather than automatically running every test for every small change.
- Report exactly which files were modified and which tests were executed.
