document.addEventListener('DOMContentLoaded', () => {
  const registerForm = document.getElementById('register-form');
  const loginForm = document.getElementById('login-form');

  const setMessage = (element, text, isError = false) => {
    if (!element) return;
    element.textContent = text;
    element.className = `form-message ${isError ? 'error' : 'success'}`;
  };

  if (registerForm) {
    registerForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const formData = new FormData(registerForm);
      const payload = Object.fromEntries(formData.entries());
      const message = document.getElementById('register-message');

      try {
        const result = await apiRequest('/auth/register', {
          method: 'POST',
          body: JSON.stringify(payload)
        });
        localStorage.setItem('playhub-customer-token', result.token);
        setMessage(message, result.message || 'Registration successful.');
        window.location.href = './my-bookings.html';
      } catch (error) {
        setMessage(message, error.message, true);
      }
    });
  }

  if (loginForm) {
    loginForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const payload = {
        mobile: document.getElementById('login-mobile').value,
        password: document.getElementById('login-password').value
      };
      const message = document.getElementById('login-message');

      try {
        const result = await apiRequest('/auth/login', {
          method: 'POST',
          body: JSON.stringify(payload)
        });
        localStorage.setItem('playhub-customer-token', result.token);
        setMessage(message, result.message || 'Login successful.');
        window.location.href = './my-bookings.html';
      } catch (error) {
        setMessage(message, error.message, true);
      }
    });
  }
});
