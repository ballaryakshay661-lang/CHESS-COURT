document.addEventListener('DOMContentLoaded', () => {
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[character]);
  const bookingForm = document.getElementById('booking-form');
  if (bookingForm) {
    const activityInput = bookingForm.querySelector('select[name="activity"]');
    const durationInput = bookingForm.querySelector('input[name="duration"]');
    const costDisplay = document.getElementById('estimated-price');

    const refreshCost = () => {
      if (costDisplay && activityInput && durationInput) {
        costDisplay.textContent = formatCurrency(estimateBookingCost(activityInput.value, durationInput.value));
      }
    };

    activityInput && activityInput.addEventListener('change', refreshCost);
    durationInput && durationInput.addEventListener('input', refreshCost);
    refreshCost();
  }

  const customerBookings = document.getElementById('customer-bookings');
  if (!customerBookings) return;

  const token = localStorage.getItem('playhub-customer-token');
  if (!token) {
    customerBookings.textContent = 'Please log in to view bookings.';
    return;
  }

  const loadBookings = async () => {
    try {
      const data = await apiRequest('/bookings/my', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const bookings = data.bookings || [];
      if (!bookings.length) {
        customerBookings.textContent = 'No bookings yet.';
        return;
      }
      customerBookings.innerHTML = bookings.map((booking) => `
        <div class="status-result">
          <strong>${escapeHtml(booking.activity)}</strong><br />
          Reference: ${escapeHtml(booking.reference)}<br />
          Resource: ${escapeHtml(booking.resourceId || 'Not assigned')}<br />
          Date: ${escapeHtml(booking.date)}<br />
          Time: ${escapeHtml(booking.startTime)}<br />
          Status: ${escapeHtml(booking.status)}
          ${['Pending', 'Confirmed'].includes(booking.status) ? `
            <div class="form-actions">
              <button type="button" class="button button-secondary" data-reference="${escapeHtml(booking.reference)}" data-action="cancel">Request cancellation</button>
              <button type="button" class="button button-secondary" data-reference="${escapeHtml(booking.reference)}" data-action="reschedule">Request reschedule</button>
            </div>
          ` : ''}
        </div>
      `).join('');
    } catch (error) {
      customerBookings.textContent = error.message;
    }
  };

  customerBookings.addEventListener('click', async (event) => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    try {
      if (button.dataset.action === 'cancel') {
        await apiRequest(`/bookings/${encodeURIComponent(button.dataset.reference)}/cancel`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify({})
        });
      } else {
        const date = window.prompt('New date (YYYY-MM-DD):');
        if (!date) return;
        const startTime = window.prompt('New start time (HH:MM):');
        if (!startTime) return;
        await apiRequest(`/bookings/${encodeURIComponent(button.dataset.reference)}/reschedule`, {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
          body: JSON.stringify({ date, startTime })
        });
      }
      await loadBookings();
    } catch (error) {
      customerBookings.textContent = error.message;
    }
  });

  loadBookings();
});
