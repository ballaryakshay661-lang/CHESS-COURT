document.addEventListener('DOMContentLoaded', () => {
  const token = () => localStorage.getItem('playhub-customer-token') || '';
  const balances = document.getElementById('rewards-balances');
  const history = document.getElementById('reward-history');
  const message = document.getElementById('rewards-message');
  const form = document.getElementById('reward-form');

  async function loadRewards() {
    if (!token()) {
      balances.textContent = 'Log in to view your PLAYCREDITS.';
      return;
    }

    try {
      const data = await apiRequest('/loyalty/me', {
        headers: { Authorization: `Bearer ${token()}` }
      });
      balances.textContent = `Badminton: ${data.badmintonCredits} credits (${data.badmintonRewardsAvailable} free hours available). Chess: ${data.chessCredits} credits (${data.chessRewardsAvailable} free hours available).`;
      history.replaceChildren();
      (data.rewardHistory || []).forEach((item) => {
        const row = document.createElement('li');
        row.textContent = item;
        history.append(row);
      });
      if (!data.rewardHistory || !data.rewardHistory.length) {
        const row = document.createElement('li');
        row.textContent = 'No redemptions yet.';
        history.append(row);
      }
    } catch (error) {
      balances.textContent = error.message;
    }
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!token()) {
      message.textContent = 'Log in before redeeming PLAYCREDITS.';
      message.className = 'form-message error';
      return;
    }
    try {
      const payload = Object.fromEntries(new FormData(form).entries());
      const result = await apiRequest('/loyalty/redeem', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token()}` },
        body: JSON.stringify(payload)
      });
      message.textContent = `${result.message} Booking reference: ${result.booking.reference}.`;
      message.className = 'form-message success';
      await loadRewards();
    } catch (error) {
      message.textContent = error.message;
      message.className = 'form-message error';
    }
  });

  loadRewards();
});
