document.addEventListener('DOMContentLoaded', () => {
  const loginView = document.getElementById('admin-login-view');
  const dashboardView = document.getElementById('admin-dashboard-view');
  const loginForm = document.getElementById('admin-login-form');
  const loginMessage = document.getElementById('admin-login-message');
  const tableBody = document.getElementById('admin-bookings-table');
  const passesTableBody = document.getElementById('admin-passes-table');

  const getToken = () => localStorage.getItem('playhub-admin-token');
  const clearToken = () => localStorage.removeItem('playhub-admin-token');
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[character]);

  function updateView(isLoggedIn) {
    loginView.classList.toggle('hidden', isLoggedIn);
    dashboardView.classList.toggle('hidden', !isLoggedIn);
  }

  function showLoginMessage(content, isError = false) {
    if (loginMessage) {
      loginMessage.textContent = content;
      loginMessage.className = `form-message ${isError ? 'error' : 'success'}`;
    }
    const dashboardMessage = document.getElementById('admin-dashboard-message');
    if (dashboardMessage) {
      dashboardMessage.textContent = content;
      dashboardMessage.className = `form-message ${isError ? 'error' : 'success'}`;
    }
  }

  async function loadDashboard() {
    try {
      const data = await apiRequest('/admin/dashboard', {
        headers: {
          Authorization: `Bearer ${getToken()}`
        }
      });

      document.getElementById('stat-total-bookings').textContent = data.stats.totalBookings ?? 0;
      document.getElementById('stat-confirmed-bookings').textContent = data.stats.confirmedBookings ?? 0;
      document.getElementById('stat-pending-bookings').textContent = data.stats.pendingBookings ?? 0;
      document.getElementById('stat-total-passes').textContent = data.stats.totalPasses ?? 0;

      const rows = (data.recentBookings || []).map((booking) => {
        let actions = `
          <div class="action-group">
            <button class="action-button confirm" data-id="${booking._id}" data-status="Confirmed">Confirm</button>
            <button class="action-button reject" data-id="${booking._id}" data-status="Rejected">Reject</button>
            <button class="action-button" data-id="${booking._id}" data-status="Completed">Complete</button>
            <button class="action-button" data-id="${booking._id}" data-payment-method="Cash">Cash paid</button>
            <button class="action-button" data-id="${booking._id}" data-payment-method="UPI">UPI paid</button>
          </div>
        `;

        if (booking.status === 'Cancellation Requested') {
          actions = `
            <div class="action-group">
              <button class="action-button confirm" data-id="${booking._id}" data-status="Cancelled">Approve Cancel</button>
              <button class="action-button reject" data-id="${booking._id}" data-status="Confirmed">Reject Cancel</button>
            </div>
          `;
        }

        if (booking.status === 'Reschedule Requested') {
          actions = `
            <div class="action-group">
              <button class="action-button confirm" data-id="${booking._id}" data-status="Rescheduled">Approve Reschedule</button>
              <button class="action-button reject" data-id="${booking._id}" data-status="Confirmed">Reject Reschedule</button>
            </div>
          `;
        }

        return `
          <tr>
            <td>${escapeHtml(booking.reference)}</td>
            <td>${escapeHtml(booking.customerName)}</td>
            <td>${escapeHtml(booking.activity)}</td>
            <td>${escapeHtml(booking.date)}</td>
            <td>${escapeHtml(booking.status)}</td>
            <td>${actions}</td>
          </tr>
        `;
      }).join('');

      tableBody.innerHTML = rows || '<tr><td colspan="6">No bookings found.</td></tr>';

      tableBody.querySelectorAll('button').forEach((button) => {
        button.addEventListener('click', async () => {
          if (button.dataset.paymentMethod) {
            await recordPayment(button.dataset.id, button.dataset.paymentMethod);
            return;
          }
          await updateStatus(button.dataset.id, button.dataset.status);
        });

        const passRows = (data.recentPasses || []).map((pass) => `
          <tr>
            <td>${escapeHtml(pass.customerName)}</td>
            <td>${escapeHtml(pass.mobile)}</td>
            <td>${escapeHtml(pass.startDate)} – ${escapeHtml(pass.expiryDate)}</td>
            <td>${escapeHtml(pass.status)}</td>
            <td>
              ${pass.status === 'Pending' ? `
                <button class="action-button confirm" data-pass-id="${pass._id}" data-pass-status="Active">Approve</button>
                <button class="action-button reject" data-pass-id="${pass._id}" data-pass-status="Rejected">Reject</button>
              ` : ''}
            </td>
          </tr>
        `).join('');
        passesTableBody.innerHTML = passRows || '<tr><td colspan="5">No pass requests found.</td></tr>';
        passesTableBody.querySelectorAll('button').forEach((button) => {
          button.addEventListener('click', () => updateChessPass(button.dataset.passId, button.dataset.passStatus));
        });
      });
    } catch (error) {
      showLoginMessage(error.message, true);
      if ([401, 403].includes(error.status)) {
        clearToken();
        updateView(false);
      }
    }
  }

  async function updateStatus(id, status) {
    try {
      await apiRequest(`/admin/bookings/${id}/status`, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${getToken()}`
        },
        body: JSON.stringify({ status, adminNotes: `Updated by admin to ${status}` })
      });
      await loadDashboard();
    } catch (error) {
      showLoginMessage(error.message, true);
    }
  }

  async function recordPayment(id, method) {
    const transactionReference = method === 'UPI'
      ? window.prompt('Enter the UPI transaction reference:')
      : '';
    if (method === 'UPI' && !transactionReference) return;

    try {
      await apiRequest(`/admin/bookings/${id}/payments`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${getToken()}`
        },
        body: JSON.stringify({
          method,
          status: 'Paid',
          transactionReference
        })
      });
      showLoginMessage(`${method} payment recorded.`, false);
    } catch (error) {
      showLoginMessage(error.message, true);
    }
  }

  async function updateChessPass(id, status) {
    try {
      await apiRequest(`/admin/chess-passes/${id}/status`, {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${getToken()}`
        },
        body: JSON.stringify({ status })
      });
      await loadDashboard();
    } catch (error) {
      showLoginMessage(error.message, true);
    }
  }

  if (getToken()) {
    updateView(true);
    loadDashboard();
  } else {
    updateView(false);
  }

  loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const username = document.getElementById('admin-username').value.trim();
    const password = document.getElementById('admin-password').value.trim();

    try {
      const result = await apiRequest('/admin/login', {
        method: 'POST',
        body: JSON.stringify({ username, password })
      });

      localStorage.setItem('playhub-admin-token', result.token);
      showLoginMessage(result.message);
      updateView(true);
      loadDashboard();
    } catch (error) {
      showLoginMessage(error.message, true);
    }
  });

  document.getElementById('admin-logout').addEventListener('click', () => {
    clearToken();
    updateView(false);
    document.getElementById('admin-login-form').reset();
  });
});
