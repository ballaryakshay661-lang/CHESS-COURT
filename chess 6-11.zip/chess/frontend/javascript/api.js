const API_BASE = '/api';

async function apiRequest(path, options = {}) {
  const { auth, ...requestOptions } = options;
  const defaultHeaders = {
    'Content-Type': 'application/json'
  };

  const response = await fetch(`${API_BASE}${path}`, {
    ...requestOptions,
    headers: {
      ...defaultHeaders,
      ...(requestOptions.headers || {}),
      ...(auth === 'admin'
        ? { Authorization: `Bearer ${localStorage.getItem('playhub-admin-token') || ''}` }
        : {})
    }
  });

  const text = await response.text();
  let payload = {};

  try {
    payload = text ? JSON.parse(text) : {};
  } catch (error) {
    payload = { message: text || 'Request failed.' };
  }

  if (!response.ok) {
    const error = new Error(payload.message || 'Request failed.');
    error.status = response.status;
    throw error;
  }

  return payload;
}
