document.addEventListener('DOMContentLoaded', () => {
  const dateInput = document.getElementById('availability-date');
  const activitySelect = document.getElementById('availability-activity');
  const checkButton = document.getElementById('check-availability');
  const resultBox = document.getElementById('availability-result');

  if (!dateInput || !activitySelect || !checkButton || !resultBox) {
    return;
  }

  const renderAvailability = (data) => {
    const slots = data.slots || [];

    resultBox.innerHTML = `
      <div class="slot-grid">
        ${slots.map((slot) => `
          <div class="slot-card ${slot.available > 0 ? 'available' : 'booked'}">
            <strong>${slot.time}</strong>
            <span>${slot.available} / ${slot.total} available</span>
          </div>
        `).join('')}
      </div>
    `;
  };

  const loadAvailability = async () => {
    const dateValue = dateInput.value;
    const activityValue = activitySelect.value;

    if (!dateValue) {
      resultBox.innerHTML = '<div class="empty-state">Select a valid date.</div>';
      return;
    }

    resultBox.innerHTML = '<div class="loading-state">Loading availability...</div>';

    try {
      const data = await apiRequest(`/availability?date=${encodeURIComponent(dateValue)}&activity=${encodeURIComponent(activityValue)}`);
      renderAvailability(data);
    } catch (error) {
      resultBox.innerHTML = `<div class="empty-state">${error.message}</div>`;
    }
  };

  checkButton.addEventListener('click', loadAvailability);
  dateInput.addEventListener('change', loadAvailability);
  activitySelect.addEventListener('change', loadAvailability);

  const today = new Date();
  dateInput.value = today.toISOString().split('T')[0];
  loadAvailability();
});
