function isIndianMobile(value) {
  return /^[6789]\d{9}$/.test(String(value).replace(/\s+/g, ''));
}

function formatCurrency(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(Number(value || 0));
}

function estimateBookingCost(activity, duration) {
  const hours = Number(duration || 1);

  if (activity === 'Badminton') {
    return 300 * hours;
  }

  return 75 * hours;
}
