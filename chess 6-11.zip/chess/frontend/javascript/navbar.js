document.addEventListener('DOMContentLoaded', () => {
  const nav = document.querySelector('.nav-links');
  if (!nav) return;

  nav.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      nav.querySelectorAll('a').forEach((item) => item.classList.remove('active'));
      link.classList.add('active');
    });
  });
});
