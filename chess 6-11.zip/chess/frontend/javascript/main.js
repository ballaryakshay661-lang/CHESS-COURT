document.addEventListener('DOMContentLoaded', () => {
  const dateField = document.querySelector('#availability-date, input[name="date"]');
  if (dateField && !dateField.value) {
    const today = new Date();
    dateField.value = today.toISOString().split('T')[0];
  }

  const bookingActivity = document.querySelector('select[name="activity"]');
  if (bookingActivity) {
    bookingActivity.addEventListener('change', () => {
      const estimate = document.querySelector('#estimated-price');
      const durationInput = document.querySelector('input[name="duration"]');
      if (estimate && durationInput) {
        estimate.textContent = formatCurrency(estimateBookingCost(bookingActivity.value, durationInput.value));
      }
    });
  }
});
