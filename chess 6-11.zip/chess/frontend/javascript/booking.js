document.addEventListener('DOMContentLoaded', () => {
  const bookingForm = document.getElementById('booking-form');
  const spotForm = document.getElementById('spot-form');
  const statusForm = document.getElementById('booking-status-form');
  const passForm = document.getElementById('pass-form');
  const passesList = document.getElementById('my-chess-passes');

  const loadChessPasses = async () => {
    if (!passesList) return;
    const token = localStorage.getItem('playhub-customer-token');
    if (!token) {
      passesList.textContent = 'Log in to view your chess pass requests.';
      return;
    }
    try {
      const { passes } = await apiRequest('/chess-passes/my', {
        headers: { Authorization: `Bearer ${token}` }
      });
      passesList.replaceChildren();
      if (!passes.length) {
        passesList.textContent = 'No chess pass requests yet.';
        return;
      }
      passes.forEach((pass) => {
        const item = document.createElement('p');
        item.textContent = `${pass.startDate} through ${pass.expiryDate} · ${pass.status}`;
        passesList.append(item);
      });
    } catch (error) {
      passesList.textContent = error.message;
    }
  };
  loadChessPasses();

  if (spotForm) {
    spotForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const payload = Object.fromEntries(new FormData(spotForm).entries());
      const messageBox = document.getElementById('spot-message');

      if (!payload.customerName || !payload.mobile || !payload.activity || !payload.date || !payload.startTime || !payload.duration) {
        messageBox.textContent = 'Please complete all required booking fields.';
        messageBox.className = 'form-message error';
        return;
      }

      if (!isIndianMobile(payload.mobile)) {
        messageBox.textContent = 'Please enter a valid Indian mobile number.';
        messageBox.className = 'form-message error';
        return;
      }

      try {
        const result = await apiRequest('/admin/bookings/spot', {
          method: 'POST',
          auth: 'admin',
          headers: { Authorization: `Bearer ${localStorage.getItem('playhub-customer-token') || ''}` },
          body: JSON.stringify(payload)
        });

        messageBox.textContent = `${result.message} Reference: ${result.booking.reference}.`;
        messageBox.className = 'form-message success';
        spotForm.reset();
      } catch (error) {
        messageBox.textContent = error.message;
        messageBox.className = 'form-message error';
      }
    });
  }

  if (bookingForm) {
    const activityInput = bookingForm.querySelector('select[name="activity"]');
    const durationInput = bookingForm.querySelector('input[name="duration"]');
    const estimateDisplay = document.getElementById('estimated-price');

    const updateEstimate = () => {
      const value = estimateBookingCost(activityInput.value, durationInput.value);
      estimateDisplay.textContent = formatCurrency(value);
    };

    activityInput.addEventListener('change', updateEstimate);
    durationInput.addEventListener('input', updateEstimate);
    updateEstimate();

    bookingForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const formData = new FormData(bookingForm);
      const payload = Object.fromEntries(formData.entries());
      const messageBox = document.getElementById('booking-message');

      if (!payload.customerName || !payload.mobile || !payload.activity || !payload.date || !payload.startTime || !payload.duration) {
        messageBox.textContent = 'Please complete all required booking fields.';
        messageBox.className = 'form-message error';
        return;
      }

      if (!isIndianMobile(payload.mobile)) {
        messageBox.textContent = 'Please enter a valid Indian mobile number.';
        messageBox.className = 'form-message error';
        return;
      }

      try {
        const result = await apiRequest('/bookings', {
          method: 'POST',
          headers: { Authorization: `Bearer ${localStorage.getItem('playhub-customer-token') || ''}` },
          body: JSON.stringify(payload)
        });

        messageBox.textContent = `${result.message} Reference: ${result.booking.reference}. Estimated cost: ${formatCurrency(result.estimatedPrice)}.`;
        messageBox.className = 'form-message success';
        bookingForm.reset();
        updateEstimate();
      } catch (error) {
        messageBox.textContent = error.message;
        messageBox.className = 'form-message error';
      }
    });
  }

  if (statusForm) {
    statusForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const reference = document.getElementById('status-reference').value.trim();
      const mobile = document.getElementById('status-mobile').value.trim();
      const messageBox = document.getElementById('status-message');
      const resultBox = document.getElementById('status-result');

      if (!reference || !localStorage.getItem('playhub-customer-token')) {
        messageBox.textContent = 'Log in and enter a booking reference.';
        messageBox.className = 'form-message error';
        return;
      }

      try {
        const result = await apiRequest(`/bookings/${encodeURIComponent(reference)}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('playhub-customer-token')}` }
        });
        const booking = result.booking;
        resultBox.classList.remove('hidden');
        resultBox.innerHTML = `
          <strong>${booking.activity}</strong><br />
          Date: ${booking.date}<br />
          Time: ${booking.startTime}<br />
          Status: ${booking.status}<br />
          Amount: ${formatCurrency(booking.amount)}
        `;
        messageBox.textContent = 'Booking found successfully.';
        messageBox.className = 'form-message success';
      } catch (error) {
        messageBox.textContent = error.message;
        messageBox.className = 'form-message error';
        resultBox.classList.add('hidden');
      }
    });
  }

  if (passForm) {
    passForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const formData = new FormData(passForm);
      const payload = Object.fromEntries(formData.entries());
      const messageBox = document.getElementById('pass-message');

      if (!payload.customerName || !payload.mobile || !payload.startDate) {
        messageBox.textContent = 'Please provide your name, mobile and start date.';
        messageBox.className = 'form-message error';
        return;
      }

      try {
        const response = await apiRequest('/chess-passes', {
          method: 'POST',
          headers: { Authorization: `Bearer ${localStorage.getItem('playhub-customer-token') || ''}` },
          body: JSON.stringify(payload)
        });

        messageBox.textContent = `${response.message} Expiry: ${response.pass.expiryDate}.`;
        messageBox.className = 'form-message success';
        passForm.reset();
        await loadChessPasses();
      } catch (error) {
        messageBox.textContent = error.message;
        messageBox.className = 'form-message error';
      }
    });
  }
});
