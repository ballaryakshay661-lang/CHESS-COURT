document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('activity-form');
  const activityList = document.getElementById('activities-list');
  const waitlistList = document.getElementById('my-waitlist');
  const message = document.getElementById('activity-message');
  const customerToken = () => localStorage.getItem('playhub-customer-token') || '';

  async function loadActivities() {
    try {
      const { activities } = await apiRequest('/activities');
      activityList.replaceChildren();
      if (!activities.length) {
        activityList.textContent = 'No activities have been posted yet.';
        return;
      }

      async function loadWaitlist() {
        if (!customerToken()) {
          waitlistList.textContent = 'Log in to view your waitlist entries.';
          return;
        }
        try {
          const { entries } = await apiRequest('/waitlist/my', {
            headers: { Authorization: `Bearer ${customerToken()}` }
          });
          waitlistList.replaceChildren();
          if (!entries.length) {
            waitlistList.textContent = 'You have no waitlist entries.';
            return;
          }
          entries.forEach((entry) => {
            const row = document.createElement('li');
            row.textContent = `${entry.activity} · ${entry.date} at ${entry.time} · ${entry.status}`;
            waitlistList.append(row);
          });
        } catch (error) {
          waitlistList.textContent = error.message;
        }
      }

      activities.forEach((activity) => {
        const card = document.createElement('article');
        card.className = 'status-result';
        const title = document.createElement('h3');
        title.textContent = activity.title;
        const details = document.createElement('p');
        details.textContent = `${activity.activity} · ${activity.date} at ${activity.time} · ${activity.availableSlots} slots · ${activity.status}`;
        card.append(title, details);

        if (activity.status === 'Open' && activity.availableSlots > 0) {
          const join = document.createElement('button');
          join.className = 'button button-primary';
          join.textContent = 'Join activity';
          join.addEventListener('click', async () => {
            try {
              await apiRequest(`/activities/${encodeURIComponent(activity._id)}/join`, {
                method: 'POST',
                headers: { Authorization: `Bearer ${customerToken()}` }
              });
              await loadActivities();
            } catch (error) {
              message.textContent = error.message;
              message.className = 'form-message error';
            }
          });
          card.append(join);
        } else {
          const waitlist = document.createElement('button');
          waitlist.className = 'button button-secondary';
          waitlist.textContent = 'Join waitlist';
          waitlist.addEventListener('click', async () => {
            try {
              await apiRequest('/waitlist', {
                method: 'POST',
                headers: { Authorization: `Bearer ${customerToken()}` },
                body: JSON.stringify({
                  activity: activity.activity,
                  date: activity.date,
                  time: activity.time
                })
              });
              message.textContent = 'You have joined the waitlist.';
              message.className = 'form-message success';
              await loadWaitlist();
            } catch (error) {
              message.textContent = error.message;
              message.className = 'form-message error';
            }
          });
          card.append(waitlist);
        }
        activityList.append(card);
      });
    } catch (error) {
      activityList.textContent = error.message;
    }
  }

  if (form) {
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const payload = Object.fromEntries(new FormData(form).entries());
      try {
        const response = await apiRequest('/activities', {
          method: 'POST',
          headers: { Authorization: `Bearer ${customerToken()}` },
          body: JSON.stringify(payload)
        });
        message.textContent = response.message;
        message.className = 'form-message success';
        form.reset();
        await loadActivities();
      } catch (error) {
        message.textContent = error.message;
        message.className = 'form-message error';
      }
    });
  }

  loadActivities();
  loadWaitlist();
});
