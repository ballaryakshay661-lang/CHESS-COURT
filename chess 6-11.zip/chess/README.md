# PLAYHUB – Courts & Chess

PLAYHUB is a vanilla HTML/CSS/JavaScript frontend with a Node.js/Express API and MongoDB persistence through Mongoose.

## Implemented workflows

- Customer registration and login; customer booking operations are scoped to the authenticated customer ID.
- MongoDB-backed reservations for `BADMINTON-1` and `CHESS-1` through `CHESS-5`. Reservations use unique 15-minute resource cells to prevent overlapping bookings across concurrent server processes.
- Advance bookings and admin-only walk-in bookings share the same MongoDB reservation path. A booking remains `Pending` until an admin confirms it, and its resource is secured before it is saved.
- Customer cancellation and rescheduling requests. A reschedule's new resource is held before an admin approves it; approval releases the old reservation afterward.
- Admin-managed cash and UPI payment records, separate from booking status. UPI payments marked paid require a transaction reference. This records payments; it does not connect to a payment gateway.
- PLAYCREDITS: one credit per completed, paid, non-reward booking; credits are separate for badminton and chess; four activity credits redeem one reserved, free 60-minute booking.
- Community activities, atomic joining, duplicate-protected waitlists, and customer/admin chess-pass request workflows.
- API security headers, in-process request limits, and MongoDB-backed request audit records for API mutations.

## Secure local setup

1. Install Node.js and run MongoDB locally.
2. From PowerShell, create `.env` only if it does not already exist:

   ```powershell
   if (-not (Test-Path .env)) { Copy-Item .env.example .env }
   ```

3. Configure the existing `.env` without sharing or committing it:
   - `MONGO_URI` points to your MongoDB database.
   - `JWT_SECRET` is a private random value at least 32 characters long.
   - `ADMIN_USERNAME` is your admin account name.
   - `ADMIN_PASSWORD` is at least 12 characters long and unique.

   The server refuses to start with a missing or weak JWT secret or weak admin bootstrap password. On startup, the configured admin password is stored as a bcrypt hash for the configured username; no default admin credentials are provided.
4. Install dependencies:

   ```powershell
   npm install
   ```

5. Start the server:

   ```powershell
   npm start
   ```

   Development mode:

   ```powershell
   npm run dev
   ```

If MongoDB cannot be reached, the HTTP server still exposes `/api/health` with database status; database-dependent API requests return HTTP 503. It does not use in-memory demo data.

Request limits are in-process and intended as a basic single-server control. Configure a shared rate limiter and proxy trust explicitly before deploying multiple workers behind a proxy. The server audits API mutation method, route template, actor role/id when available, response status, and timestamp; it does not store request bodies or credentials in audit records.

Resource reservations use unique MongoDB slot records and compensating rollback rather than transactions. This works with standalone MongoDB and prevents conflicting reservations, but a crash between reserving cells and saving a booking can leave a temporary orphan until startup reconciliation. Multi-document transactions require a MongoDB replica set; use one if strict atomic booking-plus-reservation writes are required.

## Tests

Run unit and security tests:

```powershell
npm test
```

MongoDB integration tests are skipped unless an isolated test URI is supplied. They generate a separate, uniquely named database and drop only that generated test database:

```powershell
$env:PLAYHUB_TEST_MONGO_URI = 'mongodb://127.0.0.1:27017/playhub_test'
npm test
Remove-Item Env:PLAYHUB_TEST_MONGO_URI
```

## Postman

In Postman Desktop, use **Import → Files** to import [`postman/playhub.postman_collection.json`](./postman/playhub.postman_collection.json) and [`postman/PLAYHUB Local.postman_environment.json`](./postman/PLAYHUB%20Local.postman_environment.json). Select the **PLAYHUB Local** environment and set `baseUrl` to the running server (default `http://localhost:5000`), `customerPassword`, `adminUsername`, and `adminPassword` using values configured privately on the server. Keep secret values in Postman's local/current-value fields; do not put secrets in the collection or commit/export a populated environment.

The collection fills a missing test date with tomorrow and can generate a test mobile number for first-time registration. Set `customerPassword` and run **Register Customer** once (or **Login Customer** for an existing account) to populate the selected environment's customer token. Set `adminUsername` and `adminPassword`, then run **Admin Login** to populate its admin token. Run customer-only requests after customer authentication and admin requests after admin authentication. Successful booking, spot booking, activity, and chess-pass requests save their IDs/references in environment variables for dependent requests. **Reject Customer Token on Admin API** and **Reject Missing Admin Token** verify admin authorization. `/api/health` includes a Postman test requiring a live MongoDB connection; disconnected health correctly fails that test.

For endpoint methods, request bodies, authorization, status codes, and implemented limitations, see [API.md](./API.md).

## Local URLs

- Website: http://localhost:5000/
- Admin: http://localhost:5000/admin
- API: http://localhost:5000/api
- Health: http://localhost:5000/api/health
