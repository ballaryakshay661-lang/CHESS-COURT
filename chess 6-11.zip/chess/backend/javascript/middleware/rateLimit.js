function createRateLimiter({ limit, windowMs, message, now = Date.now }) {
  if (!Number.isInteger(limit) || limit < 1 || !Number.isFinite(windowMs) || windowMs < 1) {
    throw new Error('Rate limiter requires a positive limit and window.');
  }

  const requestsByIp = new Map();

  return function rateLimit(req, res, next) {
    const currentTime = now();
    const key = req.ip || req.socket?.remoteAddress || 'unknown';
    let entry = requestsByIp.get(key);

    if (!entry || entry.expiresAt <= currentTime) {
      entry = { count: 0, expiresAt: currentTime + windowMs };
      requestsByIp.set(key, entry);
    }

    if (entry.count >= limit) {
      res.setHeader('Retry-After', String(Math.max(1, Math.ceil((entry.expiresAt - currentTime) / 1000))));
      return res.status(429).json({
        message: message || 'Too many requests. Please try again later.',
        code: 'RATE_LIMITED'
      });
    }

    entry.count += 1;
    if (requestsByIp.size > 5000) {
      for (const [ip, item] of requestsByIp) {
        if (item.expiresAt <= currentTime) requestsByIp.delete(ip);
      }
    }
    next();
  };
}

module.exports = {
  createRateLimiter,
  apiRateLimit: createRateLimiter({
    limit: 300,
    windowMs: 15 * 60 * 1000,
    message: 'Too many API requests. Please try again later.'
  }),
  authRateLimit: createRateLimiter({
    limit: 8,
    windowMs: 15 * 60 * 1000,
    message: 'Too many sign-in attempts. Please try again in 15 minutes.'
  }),
  writeRateLimit: createRateLimiter({
    limit: 60,
    windowMs: 15 * 60 * 1000,
    message: 'Too many changes from this address. Please try again later.'
  })
};
