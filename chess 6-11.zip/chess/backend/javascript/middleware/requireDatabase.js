const { mongoose } = require('../config/database');

function requireDatabase(req, res, next) {
  if (mongoose.connection.readyState !== 1) {
    return res.status(503).json({
      message: 'Database unavailable. Please try again when MongoDB is connected.',
      code: 'DATABASE_UNAVAILABLE'
    });
  }
  next();
}

module.exports = requireDatabase;
