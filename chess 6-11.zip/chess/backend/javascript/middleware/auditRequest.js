const AuditLog = require('../models/AuditLog');

function auditRequest(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();

  res.on('finish', () => {
    const routePath = req.route && req.route.path;
    const action = `${req.method} ${req.baseUrl}${routePath || req.path}`.slice(0, 200);
    const actor = req.admin || req.customer;
    const role = req.admin ? 'admin' : req.customer ? 'customer' : 'anonymous';

    AuditLog.create({
      actorId: actor && actor.id,
      role,
      action,
      statusCode: res.statusCode
    }).catch(() => {
      console.error('Audit log write failed; review MongoDB availability and server logs.');
    });
  });
  next();
}

module.exports = auditRequest;
