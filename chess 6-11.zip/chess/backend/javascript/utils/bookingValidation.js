const MOBILE_PATTERN = /^[6-9]\d{9}$/;

function isValidDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value &&
    value >= new Date().toISOString().slice(0, 10);
}

function validateBookingDetails(body, mobile, customerId, mobileError) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return { error: 'Booking details are required.' };
  }

  const customerName = String(body.customerName || '').trim();
  const activity = body.activity;
  const date = body.date;
  const startTime = body.startTime;
  const duration = Number(body.duration);
  const players = Number(body.players || 1);

  if (!customerName || customerName.length > 100) return { error: 'Enter a customer name up to 100 characters.' };
  if (!MOBILE_PATTERN.test(String(mobile || ''))) return { error: mobileError };
  if (!['Badminton', 'Chess'].includes(activity)) return { error: 'Activity must be Badminton or Chess.' };
  if (!isValidDate(date)) return { error: 'Enter a valid booking date.' };
  if (typeof startTime !== 'string' || !/^(?:0\d|1\d|2[0-3]):(?:00|15|30|45)$/.test(startTime)) {
    return { error: 'Start time must be on a 15-minute interval.' };
  }
  if (!Number.isInteger(duration) || duration < 1 || duration > 6) return { error: 'Duration must be between 1 and 6 whole hours.' };
  if (!Number.isInteger(players) || players < 1 || players > 10) return { error: 'Players must be between 1 and 10.' };

  const [hour, minute] = startTime.split(':').map(Number);
  if (hour < 8 || hour * 60 + minute + duration * 60 > 22 * 60) {
    return { error: 'Bookings must fit within opening hours (08:00–22:00).' };
  }

  return {
    value: {
      customerId,
      customerName,
      mobile,
      activity,
      date,
      startTime,
      duration,
      players,
      message: String(body.message || '').trim().slice(0, 500)
    }
  };
}

function validateBookingInput(body, customer) {
  if (!customer || !customer.id) return { error: 'A signed-in customer account is required.' };
  return validateBookingDetails(
    body,
    customer.mobile,
    customer.id,
    'Your account has an invalid mobile number.'
  );
}

function validateSpotBookingInput(body) {
  return validateBookingDetails(
    body,
    body && body.mobile,
    undefined,
    'Enter a valid Indian mobile number.'
  );
}

module.exports = {
  MOBILE_PATTERN,
  isValidDate,
  validateBookingInput,
  validateSpotBookingInput
};
