const mongoose = require('mongoose');

const resourceReservationSchema = new mongoose.Schema({
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    required: true,
    index: true
  },
  resourceId: {
    type: String,
    enum: ['BADMINTON-1', 'CHESS-1', 'CHESS-2', 'CHESS-3', 'CHESS-4', 'CHESS-5'],
    required: true
  },
  date: {
    type: String,
    required: true
  },
  slotStart: {
    type: Number,
    required: true
  }
}, {
  timestamps: true
});

resourceReservationSchema.index({ resourceId: 1, date: 1, slotStart: 1 }, { unique: true });

module.exports = mongoose.model('ResourceReservation', resourceReservationSchema);
