const mongoose = require('mongoose');

const businessSettingsSchema = new mongoose.Schema({
  name: {
    type: String,
    default: 'PLAYHUB'
  },
  openingHour: {
    type: Number,
    default: 8
  },
  closingHour: {
    type: Number,
    default: 22
  },
  slotIntervalMinutes: {
    type: Number,
    default: 60
  },
  bookingAdvanceLimitDays: {
    type: Number,
    default: 14
  },
  cancellationDeadlineHours: {
    type: Number,
    default: 2
  },
  chessTableRate: {
    type: Number,
    default: 75
  },
  badmintonRate: {
    type: Number,
    default: 300
  },
  chessPassPrice: {
    type: Number,
    default: 99
  },
  rewardsThreshold: {
    type: Number,
    default: 4
  },
  rewardValidityDays: {
    type: Number,
    default: 30
  },
  timezone: {
    type: String,
    default: 'Asia/Kolkata'
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('BusinessSettings', businessSettingsSchema);
