const mongoose = require('mongoose');

const paymentSchema = new mongoose.Schema({
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    required: true,
    index: true
  },
  method: {
    type: String,
    enum: ['Cash', 'UPI'],
    required: true
  },
  status: {
    type: String,
    enum: ['Pending', 'Paid', 'Failed', 'Refunded'],
    required: true,
    default: 'Pending'
  },
  amount: {
    type: Number,
    required: true,
    min: 0
  },
  transactionReference: {
    type: String,
    trim: true,
    maxlength: 80,
    default: ''
  },
  notes: {
    type: String,
    trim: true,
    maxlength: 500,
    default: ''
  },
  recordedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin',
    required: true
  }
}, { timestamps: true });

module.exports = mongoose.model('Payment', paymentSchema);
