const mongoose = require('mongoose');

const playerActivitySchema = new mongoose.Schema({
  hostCustomerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true
  },
  activity: {
    type: String,
    enum: ['Badminton', 'Chess'],
    required: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  date: {
    type: String,
    required: true
  },
  time: {
    type: String,
    required: true
  },
  duration: {
    type: Number,
    default: 1
  },
  format: {
    type: String,
    default: 'Casual'
  },
  availableSlots: {
    type: Number,
    default: 2
  },
  participants: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer'
  }],
  status: {
    type: String,
    enum: ['Open', 'Full', 'Cancelled'],
    default: 'Open'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('PlayerActivity', playerActivitySchema);
