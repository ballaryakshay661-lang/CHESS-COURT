const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema({
  actorId: {
    type: mongoose.Schema.Types.ObjectId,
    default: undefined
  },
  role: {
    type: String,
    enum: ['admin', 'customer', 'anonymous'],
    required: true
  },
  action: {
    type: String,
    required: true,
    maxlength: 200
  },
  statusCode: {
    type: Number,
    required: true,
    min: 100,
    max: 599
  }
}, { timestamps: { createdAt: true, updatedAt: false } });

auditLogSchema.index({ createdAt: -1 });

module.exports = mongoose.model('AuditLog', auditLogSchema);
