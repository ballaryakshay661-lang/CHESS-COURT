const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    index: true
  },
  resourceId: {
    type: String,
    enum: ['BADMINTON-1', 'CHESS-1', 'CHESS-2', 'CHESS-3', 'CHESS-4', 'CHESS-5'],
    default: undefined
  },
  isRewardBooking: {
    type: Boolean,
    default: false
  },
  requestedSlot: {
    date: String,
    startTime: String,
    duration: Number,
    resourceId: {
      type: String,
      enum: ['BADMINTON-1', 'CHESS-1', 'CHESS-2', 'CHESS-3', 'CHESS-4', 'CHESS-5']
    }
  },
  reference: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    uppercase: true
  },
  customerName: {
    type: String,
    required: true,
    trim: true
  },
  mobile: {
    type: String,
    required: true,
    trim: true
  },
  activity: {
    type: String,
    enum: ['Badminton', 'Chess'],
    required: true
  },
  date: {
    type: String,
    required: true
  },
  startTime: {
    type: String,
    required: true
  },
  duration: {
    type: Number,
    required: true,
    min: 1
  },
  players: {
    type: Number,
    required: true,
    min: 1
  },
  message: {
    type: String,
    default: ''
  },
  status: {
    type: String,
    enum: ['Pending', 'Confirmed', 'Rejected', 'Cancellation Requested', 'Cancelled', 'Reschedule Requested', 'Rescheduled', 'Completed'],
    default: 'Pending'
  },
  amount: {
    type: Number,
    default: 0
  },
  adminNotes: {
    type: String,
    default: ''
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Booking', bookingSchema);
