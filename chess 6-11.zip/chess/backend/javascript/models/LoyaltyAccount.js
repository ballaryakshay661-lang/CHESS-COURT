const mongoose = require('mongoose');

const loyaltyAccountSchema = new mongoose.Schema({
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true,
    unique: true
  },
  badmintonCredits: {
    type: Number,
    default: 0
  },
  chessCredits: {
    type: Number,
    default: 0
  },
  creditedBookingIds: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking'
  }],
  rewardHistory: [{
    type: String
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('LoyaltyAccount', loyaltyAccountSchema);
