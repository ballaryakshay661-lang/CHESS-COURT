const mongoose = require('mongoose');

const waitlistEntrySchema = new mongoose.Schema({
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true
  },
  dedupeKey: {
    type: String,
    unique: true,
    sparse: true
  },
  activity: {
    type: String,
    enum: ['Badminton', 'Chess'],
    required: true
  },
  date: {
    type: String,
    required: true
  },
  time: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['Waiting', 'Offered', 'Accepted', 'Declined'],
    default: 'Waiting'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('WaitlistEntry', waitlistEntrySchema);
