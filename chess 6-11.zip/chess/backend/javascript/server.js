require('dotenv').config();
const app = require('./app');
const { connectDatabase } = require('./config/database');
const { ensureDefaultAdmin } = require('./services/bookingService');
const { reserveExistingBookings, releaseOrphanedReservations } = require('./services/resourceService');
const { getJwtSecret } = require('./config/security');

const PORT = process.env.PORT || 5000;

async function bootstrap() {
  getJwtSecret();
  try {
    await connectDatabase();
  } catch (error) {
    console.error('MongoDB connection failed; database-backed requests will return HTTP 503.');
  }
  if (require('./config/database').mongoose.connection.readyState === 1) {
    await ensureDefaultAdmin();
    await releaseOrphanedReservations();
    await reserveExistingBookings();
  }
  const server = app.listen(PORT, () => {
    console.log(`PLAYHUB server running on http://localhost:${PORT}`);
  });
  return server;
}

if (require.main === module) {
  bootstrap().then((server) => {
    let shuttingDown = false;
    const shutdown = (signal) => {
      if (shuttingDown) return;
      shuttingDown = true;
      console.log(`${signal} received; closing PLAYHUB.`);
      server.close(async (error) => {
        try {
          await require('./config/database').mongoose.disconnect();
          if (error) {
            console.error('HTTP server shutdown failed.');
            process.exitCode = 1;
          }
        } catch (disconnectError) {
          console.error('MongoDB shutdown failed.');
          process.exitCode = 1;
        }
      });
    };
    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));
  }).catch((error) => {
    console.error(`PLAYHUB startup failed: ${error.message}`);
    process.exitCode = 1;
  });
}

module.exports = { bootstrap };
