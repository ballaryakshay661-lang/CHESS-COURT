const jwt = require('jsonwebtoken');
const { getJwtSecret } = require('../config/security');
const { mongoose } = require('../config/database');
const {
  ensureDefaultAdmin,
  validateAdminCredentials,
  getDashboardData,
  getBookings,
  createBooking,
  calculateEstimatedPrice,
  updateBookingStatus,
  getChessPasses
} = require('../services/bookingService');
const { recordPayment, getPaymentsForBooking } = require('../services/loyaltyService');
const { validateSpotBookingInput } = require('../utils/bookingValidation');

async function login(req, res) {
  try {
    const { username, password } = req.body;
    if (typeof username !== 'string' || !username.trim() || username.length > 100 ||
      typeof password !== 'string' || !password || password.length > 128) {
      return res.status(400).json({ message: 'Username and password are required.' });
    }

    const admin = await validateAdminCredentials(username, password);
    if (!admin) {
      return res.status(401).json({ message: 'Invalid admin credentials.' });
    }

    const token = jwt.sign({ id: admin._id, username: admin.username, role: admin.role }, getJwtSecret(), { expiresIn: '8h' });
    res.json({
      message: 'Admin login successful.',
      token,
      admin: { username: admin.username, role: admin.role }
    });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to log in.' });
  }
}

async function dashboard(req, res) {
  try {
    const data = await getDashboardData();
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load admin dashboard.' });
  }
}

async function bookings(req, res) {
  try {
    const bookings = await getBookings();
    res.json({ bookings });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load bookings.' });
  }
}

async function createSpotBooking(req, res) {
  try {
    const validated = validateSpotBookingInput(req.body);
    if (validated.error) return res.status(400).json({ message: validated.error });
    const estimated = calculateEstimatedPrice(validated.value.activity, validated.value.duration);
    const savedBooking = await createBooking(validated.value);
    res.status(201).json({
      message: 'Spot booking request received successfully.',
      estimatedPrice: estimated,
      booking: savedBooking
    });
  } catch (error) {
    const statusCode = error.code === 'SLOT_UNAVAILABLE' ? 409 :
      error.code === 'DATABASE_UNAVAILABLE' ? 503 : 400;
    res.status(statusCode).json({ message: error.message || 'Unable to save spot booking.' });
  }
}

async function updateStatus(req, res) {
  try {
    const { id } = req.params;
    const { status, adminNotes } = req.body;
    const validStatuses = ['Pending', 'Confirmed', 'Rejected', 'Cancellation Requested', 'Cancelled', 'Reschedule Requested', 'Rescheduled', 'Completed'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid booking status.' });
    }

    const notes = typeof adminNotes === 'string' ? adminNotes.trim().slice(0, 500) : '';
    const booking = await updateBookingStatus(id, status, notes);
    res.json({ message: 'Booking status updated.', booking });
  } catch (error) {
    const statusCode = ['SLOT_UNAVAILABLE', 'BOOKING_BUSY'].includes(error.code) ? 409 :
      error.message === 'Booking not found.' ? 404 : 400;
    res.status(statusCode).json({ message: error.message || 'Unable to update booking.' });
  }
}

async function payments(req, res) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid booking ID.' });
    }
    const records = await getPaymentsForBooking(req.params.id);
    res.json({ payments: records });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load payment records.' });
  }
}

async function createPayment(req, res) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Invalid booking ID.' });
    }
    const { method, status, transactionReference, notes } = req.body;
    if (!['Cash', 'UPI'].includes(method) ||
      !['Pending', 'Paid', 'Failed', 'Refunded'].includes(status) ||
      String(transactionReference || '').length > 80 ||
      String(notes || '').length > 500) {
      return res.status(400).json({ message: 'Provide a valid payment method, status, reference, and notes.' });
    }

    const payment = await recordPayment({
      bookingId: req.params.id,
      method,
      status,
      transactionReference: String(transactionReference || '').trim(),
      notes: String(notes || '').trim(),
      recordedBy: req.admin.id
    });
    res.status(201).json({ message: 'Payment record saved.', payment });
  } catch (error) {
    const code = error.code === 'BOOKING_NOT_FOUND' ? 404 : 400;
    res.status(code).json({ message: error.message || 'Unable to save payment record.' });
  }
}

async function chessPasses(req, res) {
  try {
    res.json({ passes: await getChessPasses() });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load chess pass requests.' });
  }
}

async function updateChessPass(req, res) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid pass ID.' });
    const { status } = req.body;
    if (!['Active', 'Rejected', 'Expired'].includes(status)) {
      return res.status(400).json({ message: 'Invalid chess pass status.' });
    }
    const ChessPass = require('../models/ChessPass');
    const pass = await ChessPass.findByIdAndUpdate(req.params.id, { status, updatedAt: new Date() }, { new: true });
    if (!pass) return res.status(404).json({ message: 'Chess pass not found.' });
    res.json({ message: 'Chess pass updated.', pass });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to update chess pass.' });
  }
}

module.exports = {
  login,
  dashboard,
  bookings,
  createSpotBooking,
  updateStatus,
  payments,
  createPayment,
  chessPasses,
  updateChessPass
};
