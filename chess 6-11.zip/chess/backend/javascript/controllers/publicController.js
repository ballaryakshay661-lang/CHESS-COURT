const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pricing = require('../config/pricing');
const Customer = require('../models/Customer');
const BusinessSettings = require('../models/BusinessSettings');
const PlayerActivity = require('../models/PlayerActivity');
const WaitlistEntry = require('../models/WaitlistEntry');
const Booking = require('../models/Booking');
const Contact = require('../models/Contact');
const { getJwtSecret } = require('../config/security');
const { validateBookingInput, MOBILE_PATTERN, isValidDate } = require('../utils/bookingValidation');
const { getLoyaltySummary, redeemReward } = require('../services/loyaltyService');
const {
  getAvailability,
  createBooking,
  requestCancellation,
  requestReschedule,
  createChessPass,
  calculateEstimatedPrice
} = require('../services/bookingService');

async function health(req, res) {
  const mongoose = require('mongoose');
  let databaseConnected = mongoose.connection.readyState === 1;
  if (databaseConnected) {
    try {
      await mongoose.connection.db.admin().command({ ping: 1 });
    } catch (error) {
      databaseConnected = false;
    }
  }
  res.status(databaseConnected ? 200 : 503).json({
    ok: databaseConnected,
    service: 'PLAYHUB API',
    database: databaseConnected ? 'connected' : 'disconnected',
    message: databaseConnected ? 'Service is running' : 'Database unavailable.',
    timestamp: new Date().toISOString()
  });
}

function pricingInfo(req, res) {
  res.json({
    badminton: {
      ...pricing.badminton,
      hourlyRate: pricing.badminton.pricePerHour,
      estimatedPriceLabel: '₹300 / hour'
    },
    chess: {
      ...pricing.chess,
      priceRange: '₹75 - ₹100 / hour',
      hourlyRate: pricing.chess.minPrice
    },
    chessPass: {
      ...pricing.chessPass,
      priceLabel: '₹99 / month'
    }
  });
}

async function availability(req, res) {
  try {
    const { date, activity } = req.query;

    if (!date || !activity) {
      return res.status(400).json({ message: 'Date and activity are required.' });
    }

    const availability = await getAvailability(date, activity);
    res.json(availability);
  } catch (error) {
    const status = error.code === 'DATABASE_UNAVAILABLE' ? 503 : 400;
    res.status(status).json({ message: error.message || 'Could not fetch availability.' });
  }
}

async function booking(req, res) {
  try {
    const validated = validateBookingInput(req.body, req.customer);
    if (validated.error) return res.status(400).json({ message: validated.error });
    const estimated = calculateEstimatedPrice(validated.value.activity, validated.value.duration);
    const savedBooking = await createBooking(validated.value);

    res.status(201).json({
      message: 'Booking request received successfully.',
      estimatedPrice: estimated,
      booking: savedBooking
    });
  } catch (error) {
    const status = error.code === 'SLOT_UNAVAILABLE' ? 409 :
      error.code === 'DATABASE_UNAVAILABLE' ? 503 : 400;
    res.status(status).json({ message: error.message || 'Unable to save booking request.' });
  }
}

async function bookingStatus(req, res) {
  try {
    const { reference } = req.params;

    if (!reference || reference.length > 40) {
      return res.status(400).json({ message: 'A valid booking reference is required.' });
    }

    const booking = await Booking.findOne({ reference: reference.toUpperCase(), customerId: req.customer.id }).lean();
    if (!booking) {
      return res.status(404).json({ message: 'No booking found for this account and reference.' });
    }

    res.json({ booking });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to fetch booking status.' });
  }
}

async function cancelBooking(req, res) {
  try {
    const { reference } = req.params;
    const { reason } = req.body;

    const booking = await requestCancellation(reference, req.customer.id, reason || '');
    res.json({ message: 'Cancellation request submitted successfully.', booking });
  } catch (error) {
    const status = error.code === 'BOOKING_BUSY' ? 409 :
      error.code === 'DATABASE_UNAVAILABLE' ? 503 : 400;
    res.status(status).json({ message: error.message || 'Could not process cancellation request.' });
  }
}

async function rescheduleBooking(req, res) {
  try {
    const { reference } = req.params;
    const { date, startTime, duration, message } = req.body;

    if (date && !isValidDate(date)) {
      return res.status(400).json({ message: 'Enter a valid reschedule date.' });
    }
    if (startTime && !/^(?:0\d|1\d|2[0-3]):(?:00|15|30|45)$/.test(startTime)) {
      return res.status(400).json({ message: 'Reschedule time must be on a 15-minute interval.' });
    }
    if (duration !== undefined && (!Number.isInteger(Number(duration)) || Number(duration) < 1 || Number(duration) > 6)) {
      return res.status(400).json({ message: 'Duration must be between 1 and 6 whole hours.' });
    }
    const booking = await requestReschedule(reference, req.customer.id, { date, startTime, duration, message });
    res.json({ message: 'Reschedule request submitted successfully.', booking });
  } catch (error) {
    const status = ['SLOT_UNAVAILABLE', 'BOOKING_BUSY'].includes(error.code) ? 409 :
      error.code === 'DATABASE_UNAVAILABLE' ? 503 : 400;
    res.status(status).json({ message: error.message || 'Could not process reschedule request.' });
  }
}

async function createPass(req, res) {
  try {
    const data = req.body;
    if (!data || !String(data.customerName || '').trim() || String(data.customerName).trim().length > 100 ||
      !MOBILE_PATTERN.test(String(req.customer.mobile || '')) || !isValidDate(data.startDate)) {
      return res.status(400).json({ message: 'A valid name and start date are required for your account.' });
    }

    const pass = await createChessPass({
      customerName: String(data.customerName).trim(),
      mobile: req.customer.mobile,
      customerId: req.customer.id,
      startDate: data.startDate,
      message: String(data.message || '').trim().slice(0, 500)
    });
    res.status(201).json({ message: 'Chess pass request submitted successfully.', pass });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to submit chess pass request.' });
  }
}

async function myChessPasses(req, res) {
  try {
    const passes = await require('../models/ChessPass').find({ customerId: req.customer.id }).sort({ createdAt: -1 }).lean();
    res.json({ passes });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load chess passes.' });
  }
}

async function contact(req, res) {
  try {
    const { name, email, message } = req.body;
    if (!name || String(name).trim().length > 100 ||
      typeof email !== 'string' || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      typeof message !== 'string' || !message.trim() || message.length > 2000) {
      return res.status(400).json({ message: 'Name, email and message are required.' });
    }
    await Contact.create({
      name: String(name).trim(),
      email: email.trim().toLowerCase(),
      message: message.trim()
    });
    res.json({ message: 'Thank you, we will contact you soon.' });
  } catch (error) {
    res.status(500).json({ message: 'Unable to send message.' });
  }
}

async function settings(req, res) {
  try {
    const settings = await BusinessSettings.findOne({}) || new BusinessSettings({});
    res.json({ settings: settings.toObject ? settings.toObject() : settings });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to fetch settings.' });
  }
}

async function registerCustomer(req, res) {
  try {
    const { name, mobile, password, displayName } = req.body;

    if (!name || String(name).trim().length > 100 || !MOBILE_PATTERN.test(String(mobile || '').trim()) ||
      typeof password !== 'string' || password.length < 8 || password.length > 128 ||
      (displayName && String(displayName).trim().length > 40)) {
      return res.status(400).json({ message: 'Provide a name, valid Indian mobile number, and password (8–128 characters).' });
    }

    const existing = await Customer.findOne({ mobile: String(mobile).trim() });
    if (existing) {
      return res.status(409).json({ message: 'An account already exists for this mobile number.' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const customer = await Customer.create({
      name: String(name).trim(),
      mobile: String(mobile).trim(),
      passwordHash,
      displayName: displayName ? String(displayName).trim() : name
    });

    const token = jwt.sign({ id: customer._id, mobile: customer.mobile, role: 'customer' }, getJwtSecret(), { expiresIn: '7d' });

    res.status(201).json({
      message: 'Registration successful.',
      token,
      customer: {
        id: customer._id,
        name: customer.name,
        mobile: customer.mobile,
        displayName: customer.displayName
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to register account.' });
  }
}

async function loginCustomer(req, res) {
  try {
    const { mobile, password } = req.body;
    if (!MOBILE_PATTERN.test(String(mobile || '').trim()) || typeof password !== 'string' || password.length > 128) {
      return res.status(400).json({ message: 'Mobile and password are required.' });
    }

    const customer = await Customer.findOne({ mobile: String(mobile).trim() });
    if (!customer) {
      return res.status(401).json({ message: 'Invalid mobile number or password.' });
    }

    const passwordMatches = await bcrypt.compare(password, customer.passwordHash);
    if (!passwordMatches) {
      return res.status(401).json({ message: 'Invalid mobile number or password.' });
    }

    const token = jwt.sign({ id: customer._id, mobile: customer.mobile, role: 'customer' }, getJwtSecret(), { expiresIn: '7d' });

    res.json({
      message: 'Login successful.',
      token,
      customer: {
        id: customer._id,
        name: customer.name,
        mobile: customer.mobile,
        displayName: customer.displayName
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to log in.' });
  }
}

async function getCustomerProfile(req, res) {
  try {
    const customer = await Customer.findById(req.customer.id).lean();
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found.' });
    }

    delete customer.passwordHash;
    res.json({ customer });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load profile.' });
  }
}

async function listMyBookings(req, res) {
  try {
    const bookings = await Booking.find({ customerId: req.customer.id }).sort({ createdAt: -1 }).lean();
    res.json({ bookings });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load bookings.' });
  }
}

async function getActivities(req, res) {
  try {
    const activities = await PlayerActivity.find({}).select('-participants').sort({ createdAt: -1 }).lean();
    res.json({ activities });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load community activities.' });
  }
}

async function createActivity(req, res) {
  try {
    const { activity, title, date, time, duration, format, availableSlots } = req.body;
    const slots = Number(availableSlots || 2);
    const activityDuration = Number(duration || 1);
    if (!['Badminton', 'Chess'].includes(activity) || typeof title !== 'string' ||
      !title.trim() || title.trim().length > 100 || !isValidDate(date) ||
      !/^(?:0\d|1\d|2[0-3]):(?:00|15|30|45)$/.test(String(time || '')) ||
      !Number.isInteger(slots) || slots < 1 || slots > 10 ||
      !Number.isInteger(activityDuration) || activityDuration < 1 || activityDuration > 6) {
      return res.status(400).json({ message: 'Provide a valid activity, title, date, time and slot count.' });
    }

    const item = await PlayerActivity.create({
      hostCustomerId: req.customer.id,
      activity,
      title: title.trim(),
      date,
      time,
      duration: activityDuration,
      format: String(format || 'Casual').trim().slice(0, 40),
      availableSlots: slots
    });

    res.status(201).json({ message: 'Activity created successfully.', activity: item });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to create activity.' });
  }
}

async function joinActivity(req, res) {
  try {
    const { activityId } = req.params;
    if (!require('mongoose').isValidObjectId(activityId)) {
      return res.status(400).json({ message: 'Invalid activity ID.' });
    }
    let activity = await PlayerActivity.findOneAndUpdate({
      _id: activityId,
      status: 'Open',
      availableSlots: { $gt: 0 },
      participants: { $ne: req.customer.id }
    }, {
      $inc: { availableSlots: -1 },
      $addToSet: { participants: req.customer.id }
    }, { new: true });

    if (!activity) {
      const current = await PlayerActivity.findById(activityId);
      if (!current) return res.status(404).json({ message: 'Activity not found.' });
      if ((current.participants || []).some((id) => id.toString() === req.customer.id)) {
        return res.status(409).json({ message: 'You already joined this activity.' });
      }
      return res.status(409).json({ message: 'This activity is currently full.' });
    }

    if (activity.availableSlots === 0) {
      activity.status = 'Full';
      await activity.save();
    }

    const publicActivity = activity.toObject();
    delete publicActivity.participants;
    res.json({ message: 'Joined activity successfully.', activity: publicActivity });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to join activity.' });
  }
}

async function addWaitlist(req, res) {
  try {
    const { activity, date, time } = req.body;
    if (!['Badminton', 'Chess'].includes(activity) || !isValidDate(date) ||
      !/^(?:0\d|1\d|2[0-3]):(?:00|15|30|45)$/.test(String(time || ''))) {
      return res.status(400).json({ message: 'Provide a valid activity, date and time.' });
    }

    let entry;
    try {
      entry = await WaitlistEntry.create({
        customerId: req.customer.id,
        dedupeKey: `${req.customer.id}:${activity}:${date}:${time}`,
        activity,
        date,
        time,
        status: 'Waiting'
      });
    } catch (error) {
      if (error.code === 11000) return res.status(409).json({ message: 'You already joined this waitlist.' });
      throw error;
    }

    const safeEntry = entry.toObject();
    delete safeEntry.dedupeKey;
    res.status(201).json({ message: 'Waitlist request saved.', entry: safeEntry });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to save waitlist request.' });
  }
}

async function myWaitlist(req, res) {
  try {
    const entries = await WaitlistEntry.find({ customerId: req.customer.id }).select('-dedupeKey').sort({ createdAt: -1 }).lean();
    res.json({ entries });
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load waitlist.' });
  }
}

async function getLoyalty(req, res) {
  try {
    res.json(await getLoyaltySummary(req.customer.id));
  } catch (error) {
    res.status(500).json({ message: error.message || 'Unable to load loyalty account.' });
  }
}

async function redeemLoyaltyReward(req, res) {
  try {
    const customer = await Customer.findById(req.customer.id).lean();
    if (!customer) return res.status(404).json({ message: 'Customer not found.' });
    const validated = validateBookingInput({
      ...req.body,
      duration: 1,
      players: 1,
      customerName: customer.name
    }, { id: req.customer.id, mobile: customer.mobile });
    if (validated.error) return res.status(400).json({ message: validated.error });

    const booking = await redeemReward({
      customerId: req.customer.id,
      bookingPayload: validated.value,
      createRewardBooking: (payload) => createBooking({ ...payload, isRewardBooking: true })
    });
    res.status(201).json({ message: 'PLAYCREDITS reward booked.', booking });
  } catch (error) {
    const status = error.code === 'SLOT_UNAVAILABLE' ? 409 :
      error.code === 'INSUFFICIENT_CREDITS' ? 400 :
        error.code === 'DATABASE_UNAVAILABLE' ? 503 : 500;
    res.status(status).json({ message: error.message || 'Unable to redeem reward.' });
  }
}

module.exports = {
  health,
  pricingInfo,
  availability,
  booking,
  bookingStatus,
  cancelBooking,
  rescheduleBooking,
  createPass,
  contact,
  settings,
  registerCustomer,
  loginCustomer,
  getCustomerProfile,
  listMyBookings,
  getActivities,
  createActivity,
  joinActivity,
  addWaitlist,
  myWaitlist,
  myChessPasses,
  getLoyalty,
  redeemLoyaltyReward
};
