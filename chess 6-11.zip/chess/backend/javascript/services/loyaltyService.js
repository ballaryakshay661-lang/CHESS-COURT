const LoyaltyAccount = require('../models/LoyaltyAccount');
const Payment = require('../models/Payment');
const Booking = require('../models/Booking');
const { mongoose } = require('../config/database');

function assertMongoReady() {
  if (mongoose.connection.readyState !== 1) {
    const error = new Error('Database unavailable. Please try again when MongoDB is connected.');
    error.code = 'DATABASE_UNAVAILABLE';
    throw error;
  }
}

async function ensureLoyaltyAccount(customerId) {
  assertMongoReady();
  try {
    return await LoyaltyAccount.findOneAndUpdate(
      { customerId },
      { $setOnInsert: { customerId, badmintonCredits: 0, chessCredits: 0 } },
      { new: true, upsert: true }
    );
  } catch (error) {
    if (error.code !== 11000) throw error;
    return LoyaltyAccount.findOne({ customerId });
  }
}

async function awardCreditForBooking(booking) {
  assertMongoReady();
  if (!booking.customerId || booking.isRewardBooking || booking.status !== 'Completed') return false;
  const payment = await Payment.findOne({ bookingId: booking._id, status: 'Paid' }).sort({ createdAt: -1, _id: -1 }).lean();
  if (!payment) return false;

  const balanceField = booking.activity === 'Badminton' ? 'badmintonCredits' : 'chessCredits';
  const update = {
    $inc: { [balanceField]: 1 },
    $addToSet: { creditedBookingIds: booking._id }
  };
  try {
    const result = await LoyaltyAccount.updateOne(
      { customerId: booking.customerId, creditedBookingIds: { $ne: booking._id } },
      update,
      { upsert: true }
    );
    return result.modifiedCount === 1 || result.upsertedCount === 1;
  } catch (error) {
    if (error.code !== 11000) throw error;
    const result = await LoyaltyAccount.updateOne(
      { customerId: booking.customerId, creditedBookingIds: { $ne: booking._id } },
      update
    );
    return result.modifiedCount === 1;
  }
}

async function recordPayment({ bookingId, method, status, transactionReference = '', notes = '', recordedBy }) {
  assertMongoReady();
  const booking = await Booking.findById(bookingId);
  if (!booking) {
    const error = new Error('Booking not found.');
    error.code = 'BOOKING_NOT_FOUND';
    throw error;
  }
  if (booking.isRewardBooking) {
    throw new Error('Complimentary reward bookings do not accept payment records.');
  }
  if (!['Cash', 'UPI'].includes(method) || !['Pending', 'Paid', 'Failed', 'Refunded'].includes(status)) {
    throw new Error('Payment method or status is invalid.');
  }
  if (method === 'UPI' && status === 'Paid' && !/^[A-Za-z0-9-]{6,80}$/.test(transactionReference)) {
    throw new Error('A valid UPI transaction reference is required for a paid record.');
  }
  const payment = await Payment.create({
    bookingId,
    method,
    status,
    amount: booking.amount,
    transactionReference,
    notes,
    recordedBy
  });
  if (booking.status === 'Completed' && status === 'Paid') {
    await awardCreditForBooking(booking);
  }
  return payment.toObject();
}

async function getPaymentsForBooking(bookingId) {
  assertMongoReady();
  return Payment.find({ bookingId }).sort({ createdAt: -1 }).lean();
}

async function getLatestPaymentStatus(bookingId) {
  assertMongoReady();
  const payment = await Payment.findOne({ bookingId }).sort({ createdAt: -1, _id: -1 }).lean();
  return payment ? payment.status : 'Unpaid';
}

async function redeemReward({ customerId, bookingPayload, createRewardBooking }) {
  assertMongoReady();
  const field = bookingPayload.activity === 'Badminton' ? 'badmintonCredits' : 'chessCredits';
  const account = await LoyaltyAccount.findOneAndUpdate(
    { customerId, [field]: { $gte: 4 } },
    { $inc: { [field]: -4 } },
    { new: true }
  );
  if (!account) {
    const error = new Error('Four PLAYCREDITS for this activity are required to redeem a free hour.');
    error.code = 'INSUFFICIENT_CREDITS';
    throw error;
  }

  let rewardBooking;
  try {
    rewardBooking = await createRewardBooking(bookingPayload);
    await LoyaltyAccount.updateOne(
      { customerId },
      { $push: { rewardHistory: `${bookingPayload.activity} reward redeemed for ${bookingPayload.date} ${bookingPayload.startTime}` } }
    );
    return rewardBooking;
  } catch (error) {
    if (rewardBooking) {
      const { releaseBookingResources } = require('./resourceService');
      await releaseBookingResources(rewardBooking._id);
      await Booking.deleteOne({ _id: rewardBooking._id });
    }
    await LoyaltyAccount.updateOne({ customerId }, { $inc: { [field]: 4 } });
    throw error;
  }
}

async function getLoyaltySummary(customerId) {
  const account = await ensureLoyaltyAccount(customerId);
  return {
    badmintonCredits: account.badmintonCredits,
    chessCredits: account.chessCredits,
    badmintonRewardsAvailable: Math.floor(account.badmintonCredits / 4),
    chessRewardsAvailable: Math.floor(account.chessCredits / 4),
    rewardHistory: account.rewardHistory || [],
    threshold: 4,
    rewardDurationMinutes: 60,
    badge: 'PLAYCREDITS'
  };
}

module.exports = {
  ensureLoyaltyAccount,
  awardCreditForBooking,
  recordPayment,
  getPaymentsForBooking,
  getLatestPaymentStatus,
  redeemReward,
  getLoyaltySummary
};
