const crypto = require('crypto');
const Booking = require('../models/Booking');
const ChessPass = require('../models/ChessPass');
const Admin = require('../models/Admin');
const pricing = require('../config/pricing');
const { mongoose } = require('../config/database');
const { getAdminBootstrapCredentials } = require('../config/security');
const BookingLock = require('../models/BookingLock');
const {
  reserveForBooking,
  releaseBookingResources,
  releaseExcept,
  releaseAdditionalSlots,
  hasReservation,
  getAvailabilityForActivity
} = require('./resourceService');
const { getLatestPaymentStatus, awardCreditForBooking } = require('./loyaltyService');

function assertMongoReady() {
  if (mongoose.connection.readyState !== 1) {
    const error = new Error('Database unavailable. Please try again when MongoDB is connected.');
    error.code = 'DATABASE_UNAVAILABLE';
    throw error;
  }
}

function normalizeDate(dateString) {
  if (!dateString) return null;
  const parsed = new Date(dateString);
  if (Number.isNaN(parsed.getTime())) return null;
  return parsed.toISOString().split('T')[0];
}

function timeToMinutes(value) {
  if (!value || typeof value !== 'string') return 0;
  const [hour, minute] = value.split(':').map(Number);
  return (hour || 0) * 60 + (minute || 0);
}

function isOverlapping(startA, durationA, startB, durationB) {
  const startMinutesA = timeToMinutes(startA);
  const endMinutesA = startMinutesA + Number(durationA || 1) * 60;
  const startMinutesB = timeToMinutes(startB);
  const endMinutesB = startMinutesB + Number(durationB || 1) * 60;

  return startMinutesA < endMinutesB && startMinutesB < endMinutesA;
}

function generateReference() {
  return `PH-${Date.now().toString().slice(-6)}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function calculateEstimatedPrice(activity, duration = 1) {
  if (activity === 'Badminton') {
    return pricing.badminton.pricePerHour * Number(duration || 1);
  }

  return pricing.chess.minPrice * Number(duration || 1);
}

function simulateStatusCounts(items, statusField = 'status') {
  return items.reduce((summary, item) => {
    summary[item[statusField]] = (summary[item[statusField]] || 0) + 1;
    return summary;
  }, {});
}

async function getBookings() {
  assertMongoReady();
  return Booking.find({}).sort({ createdAt: -1 }).lean();
}

async function getChessPasses() {
  assertMongoReady();
  return ChessPass.find({}).sort({ createdAt: -1 }).lean();
}

function actionStatusFromBookingStatus(status) {
  if (status === 'Confirmed') return 'confirmed';
  if (status === 'Rejected') return 'rejected';
  if (status === 'Cancelled') return 'cancelled';
  if (status === 'Cancellation Requested') return 'pending_cancel';
  if (status === 'Reschedule Requested') return 'pending_reschedule';
  return 'pending';
}

async function getAvailability(dateString, activity) {
  const normalizedDate = normalizeDate(dateString);
  if (!normalizedDate) {
    throw new Error('Please select a valid date.');
  }
  return getAvailabilityForActivity(normalizedDate, activity);
}

async function createBooking(payload) {
  assertMongoReady();
  const reference = generateReference();
  const booking = new Booking({
    ...payload,
    reference,
    amount: payload.isRewardBooking ? 0 : calculateEstimatedPrice(payload.activity, payload.duration),
    isRewardBooking: Boolean(payload.isRewardBooking),
    status: payload.isRewardBooking ? 'Confirmed' : 'Pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });

  const reservation = await reserveForBooking({
    bookingId: booking._id,
    activity: booking.activity,
    date: booking.date,
    startTime: booking.startTime,
    duration: booking.duration
  });
  booking.resourceId = reservation.resourceId;
  try {
    await booking.save();
  } catch (error) {
    await releaseBookingResources(booking._id);
    throw error;
  }
  return booking.toObject();
}

async function getBookingByReference(reference, mobile) {
  const normalizedReference = reference && reference.toUpperCase();

  assertMongoReady();
  return Booking.findOne({ reference: normalizedReference, mobile }).lean();
}

async function requestCancellation(reference, customerId, reason = '') {
  assertMongoReady();
  const booking = await Booking.findOne({ reference: reference.toUpperCase(), customerId }).select('_id').lean();
  if (!booking) throw new Error('Booking not found.');
  return withBookingLock(booking._id, () => requestCancellationUnlocked(reference, customerId, reason));
}

async function requestCancellationUnlocked(reference, customerId, reason = '') {
  assertMongoReady();
  const booking = await Booking.findOne({ reference: reference.toUpperCase(), customerId });
  if (!booking) {
    throw new Error('Booking not found.');
  }
  if (['Cancelled', 'Rejected', 'Completed'].includes(booking.status)) {
    throw new Error('This booking can no longer be cancelled.');
  }

  booking.status = 'Cancellation Requested';
  booking.adminNotes = reason || 'Customer requested cancellation';
  booking.updatedAt = new Date();
  await booking.save();
  return booking.toObject();
}

async function requestReschedule(reference, customerId, data) {
  assertMongoReady();
  const booking = await Booking.findOne({ reference: reference.toUpperCase(), customerId }).select('_id').lean();
  if (!booking) throw new Error('Booking not found.');
  return withBookingLock(booking._id, () => requestRescheduleUnlocked(reference, customerId, data));
}

async function requestRescheduleUnlocked(reference, customerId, data) {
  assertMongoReady();
  const booking = await Booking.findOne({ reference: reference.toUpperCase(), customerId });
  if (!booking) {
    throw new Error('Booking not found.');
  }

  if (['Cancelled', 'Rejected', 'Completed'].includes(booking.status)) {
    throw new Error('This booking can no longer be rescheduled.');
  }
  if (booking.status === 'Cancellation Requested') {
    throw new Error('A cancellation request is already awaiting review.');
  }
  if (booking.status === 'Reschedule Requested') {
    throw new Error('A reschedule request is already awaiting review.');
  }
  const requested = {
    date: data.date || booking.date,
    startTime: data.startTime || booking.startTime,
    duration: Number(data.duration || booking.duration)
  };
  const [startHour, startMinute] = requested.startTime.split(':').map(Number);
  if (startHour < 8 || startHour * 60 + startMinute + requested.duration * 60 > 22 * 60) {
    throw new Error('The requested booking must fit within opening hours (08:00–22:00).');
  }
  const reservation = await reserveForBooking({
    bookingId: booking._id,
    activity: booking.activity,
    ...requested,
    preferredResourceId: booking.resourceId
  });

  booking.status = 'Reschedule Requested';
  booking.adminNotes = `Reschedule request: ${requested.date} ${requested.startTime}`;
  booking.requestedSlot = { ...requested, resourceId: reservation.resourceId };
  if (data.message) booking.message = data.message;
  booking.updatedAt = new Date();
  try {
    await booking.save();
  } catch (error) {
    await releaseAdditionalSlots({
      bookingId: booking._id,
      resourceId: reservation.resourceId,
      date: requested.date,
      slots: reservation.slots,
      keepResourceId: booking.resourceId,
      keepDate: booking.date,
      keepSlots: require('./resourceService').reservationSlots(booking.startTime, booking.duration)
    });
    throw error;
  }
  return booking.toObject();
}

async function createChessPass(payload) {
  assertMongoReady();
  const startDate = normalizeDate(payload.startDate);
  const expiryDate = new Date(new Date(startDate).setMonth(new Date(startDate).getMonth() + 1)).toISOString().split('T')[0];

  const passPayload = {
    ...payload,
    startDate,
    expiryDate,
    status: 'Pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const pass = new ChessPass(passPayload);
  await pass.save();
  return pass.toObject();
}

async function ensureDefaultAdmin() {
  assertMongoReady();
  const { username, password } = getAdminBootstrapCredentials();
  const bcrypt = require('bcryptjs');
  const passwordHash = await bcrypt.hash(password, 12);
  return Admin.findOneAndUpdate(
    { username },
    { $set: { passwordHash, role: 'admin' }, $setOnInsert: { username } },
    { new: true, upsert: true, runValidators: true }
  );
}

async function validateAdminCredentials(username, password) {
  assertMongoReady();
  const { username: configuredUsername } = getAdminBootstrapCredentials();
  if (String(username).trim().toLowerCase() !== configuredUsername) return null;
  const admin = await Admin.findOne({ username: configuredUsername });
  if (!admin) return null;
  const bcrypt = require('bcryptjs');
  const isValid = await bcrypt.compare(password, admin.passwordHash);
  return isValid && admin.role === 'admin' ? admin : null;
}

async function getDashboardData() {
  assertMongoReady();
  const bookings = await getBookings();
  const chessPasses = await getChessPasses();
  return {
    stats: {
      totalBookings: bookings.length,
      confirmedBookings: bookings.filter((booking) => ['Confirmed', 'Rescheduled'].includes(booking.status)).length,
      pendingBookings: bookings.filter((booking) => booking.status === 'Pending').length,
      totalPasses: chessPasses.length,
      cancellations: bookings.filter((booking) => booking.status === 'Cancelled').length
    },
    byStatus: simulateStatusCounts(bookings),
    recentBookings: bookings.slice(0, 8),
    recentPasses: chessPasses.slice(0, 8)
  };
}

async function updateBookingStatus(id, status, adminNotes = '') {
  return withBookingLock(id, () => updateBookingStatusUnlocked(id, status, adminNotes));
}

async function updateBookingStatusUnlocked(id, status, adminNotes = '') {
  assertMongoReady();
  const booking = await Booking.findById(id);
  if (!booking) throw new Error('Booking not found.');
  if (status === 'Completed' && !['Confirmed', 'Rescheduled', 'Completed'].includes(booking.status)) {
    throw new Error('Only a confirmed booking can be completed.');
  }
  if (status === 'Completed' && !booking.isRewardBooking && await getLatestPaymentStatus(booking._id) !== 'Paid') {
    throw new Error('A paid payment record is required before completing this booking.');
  }

  if (status === 'Rescheduled') {
    if (!booking.requestedSlot || !booking.requestedSlot.date || !booking.requestedSlot.startTime || !booking.requestedSlot.resourceId) {
      throw new Error('There is no secured reschedule request to approve.');
    }
    booking.date = booking.requestedSlot.date;
    booking.startTime = booking.requestedSlot.startTime;
    booking.duration = booking.requestedSlot.duration;
    booking.resourceId = booking.requestedSlot.resourceId;
  } else if (status === 'Confirmed') {
    if (booking.requestedSlot && booking.requestedSlot.date && booking.requestedSlot.startTime) {
      const currentSlots = require('./resourceService').reservationSlots(booking.startTime, booking.duration);
      await releaseAdditionalSlots({
        bookingId: booking._id,
        resourceId: booking.requestedSlot.resourceId,
        date: booking.requestedSlot.date,
        slots: require('./resourceService').reservationSlots(booking.requestedSlot.startTime, booking.requestedSlot.duration),
        keepResourceId: booking.resourceId,
        keepDate: booking.date,
        keepSlots: currentSlots
      });
      booking.requestedSlot = undefined;
    }
    const secured = booking.resourceId && await hasReservation({
      bookingId: booking._id,
      resourceId: booking.resourceId,
      date: booking.date,
      startTime: booking.startTime,
      duration: booking.duration
    });
    if (!secured) {
      const reservation = await reserveForBooking({
        bookingId: booking._id,
        activity: booking.activity,
        date: booking.date,
        startTime: booking.startTime,
        duration: booking.duration,
        preferredResourceId: booking.resourceId
      });
      booking.resourceId = reservation.resourceId;
    }
  } else if (['Rejected', 'Cancelled', 'Completed'].includes(status)) {
    if (booking.requestedSlot && booking.requestedSlot.date && booking.requestedSlot.startTime) {
      const requestedSlots = require('./resourceService').reservationSlots(
        booking.requestedSlot.startTime,
        booking.requestedSlot.duration
      );
      await releaseAdditionalSlots({
        bookingId: booking._id,
        resourceId: booking.requestedSlot.resourceId,
        date: booking.requestedSlot.date,
        slots: requestedSlots,
        keepResourceId: booking.resourceId,
        keepDate: booking.date,
        keepSlots: require('./resourceService').reservationSlots(booking.startTime, booking.duration)
      });
      booking.requestedSlot = undefined;
    }
  }

  booking.status = status;
  booking.adminNotes = adminNotes;
  booking.updatedAt = new Date();
  await booking.save();

  if (status === 'Rescheduled') {
    const committedSlots = require('./resourceService').reservationSlots(booking.startTime, booking.duration);
    await releaseExcept({
      bookingId: booking._id,
      resourceId: booking.resourceId,
      date: booking.date,
      slots: committedSlots
    });
    booking.requestedSlot = undefined;
    await booking.save();
  } else if (['Rejected', 'Cancelled', 'Completed'].includes(status)) {
    await releaseBookingResources(booking._id);
  }
  if (status === 'Completed') await awardCreditForBooking(booking);
  return booking.toObject();
}

async function withBookingLock(bookingId, operation) {
  assertMongoReady();
  await BookingLock.init();
  const now = new Date();
  await BookingLock.deleteOne({ bookingId, expiresAt: { $lte: now } });

  let lock;
  try {
    lock = await BookingLock.create({
      bookingId,
      expiresAt: new Date(now.getTime() + 2 * 60 * 1000)
    });
  } catch (error) {
    if (error.code !== 11000) throw error;
    const busy = new Error('Another operation for this booking is already in progress. Try again shortly.');
    busy.code = 'BOOKING_BUSY';
    throw busy;
  }

  try {
    return await operation();
  } finally {
    await BookingLock.deleteOne({ _id: lock._id });
  }
}

module.exports = {
  getAvailability,
  createBooking,
  getBookingByReference,
  requestCancellation,
  requestReschedule,
  createChessPass,
  ensureDefaultAdmin,
  validateAdminCredentials,
  getDashboardData,
  updateBookingStatus,
  calculateEstimatedPrice,
  timeToMinutes,
  isOverlapping,
  getBookings,
  getChessPasses,
  actionStatusFromBookingStatus,
  normalizeDate,
  withBookingLock
};
