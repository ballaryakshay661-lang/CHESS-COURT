const ResourceReservation = require('../models/ResourceReservation');
const Booking = require('../models/Booking');
const { mongoose } = require('../config/database');

const RESOURCES = {
  Badminton: ['BADMINTON-1'],
  Chess: ['CHESS-1', 'CHESS-2', 'CHESS-3', 'CHESS-4', 'CHESS-5']
};
let reservationIndexesReady;

function assertMongoReady() {
  if (mongoose.connection.readyState !== 1) {
    const error = new Error('Database unavailable. Please try again when MongoDB is connected.');
    error.code = 'DATABASE_UNAVAILABLE';
    throw error;
  }
}

function reservationSlots(startTime, duration) {
  const [hours, minutes] = startTime.split(':').map(Number);
  const start = hours * 60 + minutes;
  const end = start + Number(duration) * 60;
  const slots = [];
  for (let slotStart = start; slotStart < end; slotStart += 15) {
    slots.push(slotStart);
  }
  return slots;
}

function isDuplicateKeyError(error) {
  return error.code === 11000 || (Array.isArray(error.writeErrors) && error.writeErrors.some((item) => item.code === 11000));
}

async function ensureReservationIndexes() {
  reservationIndexesReady ||= ResourceReservation.init();
  await reservationIndexesReady;
}

async function reserveForBooking({ bookingId, activity, date, startTime, duration, preferredResourceId }) {
  assertMongoReady();
  await ensureReservationIndexes();
  const resources = [...(RESOURCES[activity] || [])];
  if (preferredResourceId && resources.includes(preferredResourceId)) {
    resources.splice(resources.indexOf(preferredResourceId), 1);
    resources.unshift(preferredResourceId);
  }
  const slots = reservationSlots(startTime, duration);

  for (const resourceId of resources) {
    const existing = await ResourceReservation.find({
      bookingId,
      resourceId,
      date,
      slotStart: { $in: slots }
    }).distinct('slotStart');
    const missingSlots = slots.filter((slotStart) => !existing.includes(slotStart));

    try {
      if (missingSlots.length) {
        await ResourceReservation.insertMany(missingSlots.map((slotStart) => ({
          bookingId,
          resourceId,
          date,
          slotStart
        })), { ordered: false });
      }
      return { resourceId, slots };
    } catch (error) {
      await ResourceReservation.deleteMany({
        bookingId,
        resourceId,
        date,
        slotStart: { $in: missingSlots }
      });
      if (isDuplicateKeyError(error)) continue;
      throw error;
    }
  }

  const error = new Error('No resource is available for that overlapping time slot.');
  error.code = 'SLOT_UNAVAILABLE';
  throw error;
}

async function releaseBookingResources(bookingId) {
  assertMongoReady();
  await ResourceReservation.deleteMany({ bookingId });
}

async function releaseExcept({ bookingId, resourceId, date, slots }) {
  assertMongoReady();
  await ResourceReservation.deleteMany({
    bookingId,
    $nor: [{ resourceId, date, slotStart: { $in: slots } }]
  });
}

async function releaseAdditionalSlots({ bookingId, resourceId, date, slots, keepResourceId, keepDate, keepSlots }) {
  assertMongoReady();
  const removableSlots = slots.filter((slot) => !(resourceId === keepResourceId && date === keepDate && keepSlots.includes(slot)));
  if (removableSlots.length) {
    await ResourceReservation.deleteMany({
      bookingId,
      resourceId,
      date,
      slotStart: { $in: removableSlots }
    });
  }
}

async function hasReservation({ bookingId, resourceId, date, startTime, duration }) {
  assertMongoReady();
  const slots = reservationSlots(startTime, duration);
  const count = await ResourceReservation.countDocuments({ bookingId, resourceId, date, slotStart: { $in: slots } });
  return count === slots.length;
}

async function getAvailabilityForActivity(date, activity) {
  assertMongoReady();
  const resources = RESOURCES[activity];
  if (!resources) {
    const error = new Error('Activity must be Badminton or Chess.');
    error.code = 'INVALID_ACTIVITY';
    throw error;
  }

  const slots = [];
  for (let hour = 8; hour < 22; hour += 1) {
    const start = hour * 60;
    const occupied = await ResourceReservation.distinct('resourceId', {
      date,
      resourceId: { $in: resources },
      slotStart: { $gte: start, $lt: start + 60 }
    });
    slots.push({
      time: `${String(hour).padStart(2, '0')}:00`,
      available: resources.length - occupied.length,
      occupied: occupied.length,
      total: resources.length,
      status: occupied.length < resources.length ? 'Available' : 'Booked'
    });
  }
  return { date, activity, slots };
}

async function reserveExistingBookings() {
  assertMongoReady();
  await ensureReservationIndexes();
  const bookings = await Booking.find({
    status: { $nin: ['Rejected', 'Cancelled', 'Completed'] }
  }).sort({ createdAt: 1 });

  for (const booking of bookings) {
    const slots = reservationSlots(booking.startTime, booking.duration);
    const existingCount = booking.resourceId
      ? await ResourceReservation.countDocuments({
        bookingId: booking._id,
        resourceId: booking.resourceId,
        date: booking.date,
        slotStart: { $in: slots }
      })
      : 0;
    if (existingCount === slots.length) continue;

    try {
      const reservation = await reserveForBooking({
        bookingId: booking._id,
        activity: booking.activity,
        date: booking.date,
        startTime: booking.startTime,
        duration: booking.duration,
        preferredResourceId: booking.resourceId
      });
      booking.resourceId = reservation.resourceId;
      await booking.save();
    } catch (error) {
      if (error.code !== 'SLOT_UNAVAILABLE') throw error;
      if (booking.status === 'Confirmed') {
        booking.status = 'Pending';
        booking.adminNotes = 'Legacy booking could not be secured because the resource is occupied; review required.';
        await booking.save();
      }
      console.error(`Legacy booking ${booking.reference} has no secured resource: ${error.message}`);
    }
  }
}

async function releaseOrphanedReservations() {
  assertMongoReady();
  await ensureReservationIndexes();
  const bookingIds = await Booking.distinct('_id');
  const result = await ResourceReservation.deleteMany({ bookingId: { $nin: bookingIds } });
  return result.deletedCount;
}

module.exports = {
  RESOURCES,
  reservationSlots,
  reserveForBooking,
  releaseBookingResources,
  releaseExcept,
  releaseAdditionalSlots,
  hasReservation,
  getAvailabilityForActivity,
  releaseOrphanedReservations,
  reserveExistingBookings
};
