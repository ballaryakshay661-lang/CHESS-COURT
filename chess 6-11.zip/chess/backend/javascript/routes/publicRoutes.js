const express = require('express');
const { authenticateCustomer } = require('../middleware/auth');
const requireDatabase = require('../middleware/requireDatabase');
const { authRateLimit, writeRateLimit } = require('../middleware/rateLimit');
const {
  health,
  pricingInfo,
  availability,
  booking,
  bookingStatus,
  cancelBooking,
  rescheduleBooking,
  createPass,
  myChessPasses,
  contact,
  settings,
  registerCustomer,
  loginCustomer,
  getCustomerProfile,
  listMyBookings,
  getActivities,
  createActivity,
  joinActivity,
  addWaitlist,
  myWaitlist,
  getLoyalty,
  redeemLoyaltyReward
} = require('../controllers/publicController');

const router = express.Router();

router.get('/health', health);
router.get('/pricing', pricingInfo);
router.use(requireDatabase);
router.get('/settings', settings);
router.get('/availability', availability);
router.post('/auth/register', authRateLimit, registerCustomer);
router.post('/auth/login', authRateLimit, loginCustomer);
router.get('/auth/me', authenticateCustomer, getCustomerProfile);
router.post('/bookings', authenticateCustomer, writeRateLimit, booking);
router.get('/bookings/:reference', authenticateCustomer, bookingStatus);
router.get('/bookings/my', authenticateCustomer, listMyBookings);
router.post('/bookings/:reference/cancel', authenticateCustomer, writeRateLimit, cancelBooking);
router.post('/bookings/:reference/reschedule', authenticateCustomer, writeRateLimit, rescheduleBooking);
router.post('/chess-passes', authenticateCustomer, writeRateLimit, createPass);
router.get('/chess-passes/my', authenticateCustomer, myChessPasses);
router.post('/contact', writeRateLimit, contact);
router.get('/activities', getActivities);
router.post('/activities', authenticateCustomer, writeRateLimit, createActivity);
router.post('/activities/:activityId/join', authenticateCustomer, writeRateLimit, joinActivity);
router.post('/waitlist', authenticateCustomer, writeRateLimit, addWaitlist);
router.get('/waitlist/my', authenticateCustomer, myWaitlist);
router.get('/loyalty/me', authenticateCustomer, getLoyalty);
router.post('/loyalty/redeem', authenticateCustomer, writeRateLimit, redeemLoyaltyReward);

module.exports = router;
