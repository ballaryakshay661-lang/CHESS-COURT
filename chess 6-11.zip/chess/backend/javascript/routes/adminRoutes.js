const express = require('express');
const { authenticateAdmin } = require('../middleware/auth');
const requireDatabase = require('../middleware/requireDatabase');
const { authRateLimit, writeRateLimit } = require('../middleware/rateLimit');
const {
  login,
  dashboard,
  bookings,
  createSpotBooking,
  updateStatus,
  payments,
  createPayment,
  chessPasses,
  updateChessPass
} = require('../controllers/adminController');

const router = express.Router();

router.use(requireDatabase);
router.post('/login', authRateLimit, login);
router.get('/dashboard', authenticateAdmin, dashboard);
router.get('/bookings', authenticateAdmin, bookings);
router.post('/bookings/spot', authenticateAdmin, writeRateLimit, createSpotBooking);
router.patch('/bookings/:id/status', authenticateAdmin, writeRateLimit, updateStatus);
router.get('/bookings/:id/payments', authenticateAdmin, payments);
router.post('/bookings/:id/payments', authenticateAdmin, writeRateLimit, createPayment);
router.get('/chess-passes', authenticateAdmin, chessPasses);
router.patch('/chess-passes/:id/status', authenticateAdmin, writeRateLimit, updateChessPass);

module.exports = router;
