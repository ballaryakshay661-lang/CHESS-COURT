const path = require('path');
const express = require('express');
const publicRoutes = require('./routes/publicRoutes');
const adminRoutes = require('./routes/adminRoutes');
const requireDatabase = require('./middleware/requireDatabase');
const securityHeaders = require('./middleware/securityHeaders');
const { apiRateLimit } = require('./middleware/rateLimit');
const auditRequest = require('./middleware/auditRequest');

const app = express();

app.use(securityHeaders);
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use((req, res, next) => {
  req.body ||= {};
  next();
});

app.use('/api', apiRateLimit, auditRequest, publicRoutes);
app.use('/api/admin', requireDatabase);
app.use('/api/admin', adminRoutes);

const frontendPath = path.join(__dirname, '../../frontend');
app.use(express.static(frontendPath));

app.get('/admin', (req, res) => {
  res.sendFile(path.join(frontendPath, 'admin.html'));
});

app.get('/admin.html', (req, res) => {
  res.sendFile(path.join(frontendPath, 'admin.html'));
});

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ message: 'API endpoint not found.' });
  }
  res.sendFile(path.join(frontendPath, 'index.html'));
});

module.exports = app;
