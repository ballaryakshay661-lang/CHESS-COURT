const mongoose = require('mongoose');

async function connectDatabase() {
  const mongoUri = process.env.MONGO_URI;
  if (!mongoUri) {
    throw new Error('MONGO_URI must be configured before starting PLAYHUB.');
  }
  mongoose.set('bufferCommands', false);
  await mongoose.connect(mongoUri, { serverSelectionTimeoutMS: 5000 });
  console.log('MongoDB connected successfully');
  return true;
}

module.exports = {
  connectDatabase,
  mongoose
};
