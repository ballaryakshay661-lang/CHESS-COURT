module.exports = {
  badminton: {
    pricePerHour: 300,
    capacity: 1,
    label: 'Badminton Court',
    currency: 'INR'
  },
  chess: {
    pricePerHour: 75,
    capacity: 5,
    label: 'Chess Table',
    currency: 'INR',
    minPrice: 75,
    maxPrice: 100
  },
  chessPass: {
    monthlyPrice: 99,
    currency: 'INR'
  }
};
