function getJwtSecret() {
  const secret = process.env.JWT_SECRET;
  if (!secret || Buffer.byteLength(secret, 'utf8') < 32 || /^(replace|change|your|example)[-_]/i.test(secret)) {
    throw new Error('JWT_SECRET must be configured with at least 32 characters.');
  }
  return secret;
}

function getAdminBootstrapCredentials() {
  const username = String(process.env.ADMIN_USERNAME || '').trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || '');
  if (!username || !password || password.length < 12 ||
    /^(choose|replace|change|your|example)[-_]/i.test(username) ||
    /^(choose|replace|change|your|example)[-_]/i.test(password)) {
    throw new Error('Configure ADMIN_USERNAME and an ADMIN_PASSWORD of at least 12 characters.');
  }
  return { username, password };
}

module.exports = {
  getJwtSecret,
  getAdminBootstrapCredentials
};
