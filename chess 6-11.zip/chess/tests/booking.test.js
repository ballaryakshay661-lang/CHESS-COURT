const test = require('node:test');
const assert = require('node:assert/strict');

const {
  calculateEstimatedPrice,
  isOverlapping,
  timeToMinutes
} = require('../backend/javascript/services/bookingService');
const { reservationSlots, RESOURCES } = require('../backend/javascript/services/resourceService');

test('calculateEstimatedPrice returns the badminton hourly rate', () => {
  assert.equal(calculateEstimatedPrice('Badminton', 2), 600);
});

test('calculateEstimatedPrice returns the chess table rate', () => {
  assert.equal(calculateEstimatedPrice('Chess', 2), 150);
});

test('timeToMinutes converts clock values correctly', () => {
  assert.equal(timeToMinutes('18:30'), 1110);
});

test('overlapping bookings are detected', () => {
  assert.equal(isOverlapping('18:00', 2, '19:00', 1), true);
});

test('non-overlapping bookings are allowed', () => {
  assert.equal(isOverlapping('18:00', 1, '19:30', 1), false);
});

test('resource inventory uses one badminton court and five independent chess tables', () => {
  assert.deepEqual(RESOURCES.Badminton, ['BADMINTON-1']);
  assert.deepEqual(RESOURCES.Chess, ['CHESS-1', 'CHESS-2', 'CHESS-3', 'CHESS-4', 'CHESS-5']);
});

test('reservation cells represent every quarter hour of a booking', () => {
  assert.deepEqual(reservationSlots('18:15', 1), [1095, 1110, 1125, 1140]);
});
