# Project Instructions

- Read AGENTS.md before making changes.
- Do not scan the entire project for every prompt.
- Do not read node_modules, .git, dist, build, coverage or uploads.
- Do not read unrelated files.
- Start with the exact files mentioned in my prompt.
- Read only directly related files when necessary.
- Reuse existing project structure and code.
- Do not rewrite working files unnecessarily.
- Do not inspect every file unless explicitly requested.
- Do not run full-project searches unless necessary.
- Make the smallest possible changes.
- Run only relevant tests after changes.
- Ask before changing unrelated files.