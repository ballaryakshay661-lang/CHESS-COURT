const test = require('node:test');
const assert = require('node:assert/strict');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const { authenticateAdmin, authenticateCustomer } = require('../backend/javascript/middleware/auth');
const requireDatabase = require('../backend/javascript/middleware/requireDatabase');
const { getJwtSecret } = require('../backend/javascript/config/security');
const { validateBookingInput, validateSpotBookingInput } = require('../backend/javascript/utils/bookingValidation');
const { getBookings } = require('../backend/javascript/services/bookingService');
const securityHeaders = require('../backend/javascript/middleware/securityHeaders');
const { createRateLimiter } = require('../backend/javascript/middleware/rateLimit');

const originalSecret = process.env.JWT_SECRET;
const testSecret = 'test-secret-with-more-than-thirty-two-characters';

function responseRecorder() {
  return {
    statusCode: 200,
    body: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(body) {
      this.body = body;
      return this;
    }
  };
}

test('JWT secrets shorter than 32 bytes are rejected', () => {
  process.env.JWT_SECRET = 'short';
  assert.throws(() => getJwtSecret(), /at least 32 characters/);
});

test('admin middleware rejects valid tokens without the admin role', () => {
  process.env.JWT_SECRET = testSecret;
  const token = jwt.sign({ id: new mongoose.Types.ObjectId().toString(), role: 'customer' }, testSecret);
  const response = responseRecorder();
  let nextCalled = false;
  authenticateAdmin({ headers: { authorization: `Bearer ${token}` } }, response, () => { nextCalled = true; });
  assert.equal(response.statusCode, 403);
  assert.equal(nextCalled, false);
});

test('admin middleware accepts a valid admin token', () => {
  process.env.JWT_SECRET = testSecret;
  const token = jwt.sign({ id: new mongoose.Types.ObjectId().toString(), role: 'admin' }, testSecret);
  const response = responseRecorder();
  let nextCalled = false;
  authenticateAdmin({ headers: { authorization: `Bearer ${token}` } }, response, () => { nextCalled = true; });
  assert.equal(nextCalled, true);
  assert.equal(response.statusCode, 200);
});

test('customer middleware rejects tokens without a customer role and valid id', () => {
  process.env.JWT_SECRET = testSecret;
  const token = jwt.sign({ id: 'not-an-object-id', role: 'customer' }, testSecret);
  const response = responseRecorder();
  authenticateCustomer({ headers: { authorization: `Bearer ${token}` } }, response, () => {});
  assert.equal(response.statusCode, 403);
});

test('booking input validation binds the owner and validates schedule fields', () => {
  const customer = { id: new mongoose.Types.ObjectId().toString(), mobile: '9876543210' };
  const valid = validateBookingInput({
    customerName: 'Customer',
    activity: 'Badminton',
    date: '2099-12-30',
    startTime: '10:15',
    duration: '1',
    players: '2',
    mobile: '0000000000'
  }, customer);
  assert.equal(valid.value.customerId, customer.id);
  assert.equal(valid.value.mobile, customer.mobile);
  assert.equal(validateBookingInput({ activity: 'Badminton' }, customer).error !== undefined, true);
});

test('spot booking validation accepts walk-in contact details without a customer owner', () => {
  const valid = validateSpotBookingInput({
    customerName: 'Walk-in Customer',
    mobile: '9876543210',
    activity: 'Chess',
    date: '2099-12-30',
    startTime: '10:15',
    duration: '1'
  });
  assert.equal(valid.value.customerId, undefined);
  assert.equal(valid.value.mobile, '9876543210');
  assert.match(validateSpotBookingInput({ customerName: 'Walk-in Customer', mobile: '123' }).error, /valid Indian mobile number/);
});

test('disconnected database returns a clear API error and rejects data reads', async () => {
  assert.notEqual(mongoose.connection.readyState, 1);
  const response = responseRecorder();
  let nextCalled = false;
  requireDatabase({}, response, () => { nextCalled = true; });
  assert.equal(response.statusCode, 503);
  assert.equal(response.body.code, 'DATABASE_UNAVAILABLE');
  assert.equal(nextCalled, false);
  await assert.rejects(getBookings(), { code: 'DATABASE_UNAVAILABLE' });
});

test('security headers are applied and HSTS is sent only over HTTPS', () => {
  const headers = {};
  const response = { setHeader: (name, value) => { headers[name] = value; } };
  let nextCalled = false;
  securityHeaders({ secure: false }, response, () => { nextCalled = true; });
  assert.equal(headers['X-Content-Type-Options'], 'nosniff');
  assert.equal(headers['X-Frame-Options'], 'DENY');
  assert.equal(headers['Strict-Transport-Security'], undefined);
  assert.equal(nextCalled, true);

  securityHeaders({ secure: true }, response, () => {});
  assert.match(headers['Strict-Transport-Security'], /max-age=31536000/);
});

test('rate limiter rejects requests over the limit and resets after its window', () => {
  let now = 1000;
  const limiter = createRateLimiter({ limit: 2, windowMs: 1000, now: () => now });
  const invoke = () => {
    const response = {
      statusCode: 200,
      headers: {},
      setHeader(name, value) { this.headers[name] = value; },
      status(code) { this.statusCode = code; return this; },
      json(body) { this.body = body; return this; }
    };
    let nextCalled = false;
    limiter({ ip: '192.0.2.1' }, response, () => { nextCalled = true; });
    return { response, nextCalled };
  };

  assert.equal(invoke().nextCalled, true);
  assert.equal(invoke().nextCalled, true);
  const limited = invoke();
  assert.equal(limited.response.statusCode, 429);
  assert.equal(limited.response.body.code, 'RATE_LIMITED');
  assert.equal(limited.response.headers['Retry-After'], '1');
  now += 1000;
  assert.equal(invoke().nextCalled, true);
});

test.after(() => {
  if (originalSecret === undefined) delete process.env.JWT_SECRET;
  else process.env.JWT_SECRET = originalSecret;
});
