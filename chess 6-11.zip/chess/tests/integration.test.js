const test = require('node:test');
const assert = require('node:assert/strict');
const mongoose = require('mongoose');
const Booking = require('../backend/javascript/models/Booking');
const LoyaltyAccount = require('../backend/javascript/models/LoyaltyAccount');
const PlayerActivity = require('../backend/javascript/models/PlayerActivity');
const ResourceReservation = require('../backend/javascript/models/ResourceReservation');
const WaitlistEntry = require('../backend/javascript/models/WaitlistEntry');
const ChessPass = require('../backend/javascript/models/ChessPass');
const AuditLog = require('../backend/javascript/models/AuditLog');
const {
  connectDatabase
} = require('../backend/javascript/config/database');
const {
  createBooking,
  requestCancellation,
  requestReschedule,
  updateBookingStatus
} = require('../backend/javascript/services/bookingService');
const { releaseOrphanedReservations } = require('../backend/javascript/services/resourceService');
const {
  recordPayment,
  getLoyaltySummary,
  redeemReward
} = require('../backend/javascript/services/loyaltyService');
const { joinActivity, addWaitlist } = require('../backend/javascript/controllers/publicController');

const configuredTestUri = process.env.PLAYHUB_TEST_MONGO_URI;

function invokeController(controller, req) {
  let statusCode = 200;
  let body;
  const res = {
    status(code) {
      statusCode = code;
      return this;
    },
    json(value) {
      body = value;
      return this;
    }
  };
  return Promise.resolve(controller(req, res)).then(() => ({ statusCode, body }));
}

test('MongoDB booking, payment, rewards, cancellation, rescheduling and community workflows', {
  skip: !configuredTestUri
}, async () => {
  const databaseUrl = new URL(configuredTestUri);
  databaseUrl.pathname = `/playhub_test_${Date.now()}_${process.pid}`;
  process.env.MONGO_URI = databaseUrl.toString();

  await connectDatabase();
  await mongoose.connection.dropDatabase();
  await Promise.all([
    ResourceReservation.init(),
    WaitlistEntry.init(),
    LoyaltyAccount.init()
  ]);

  try {
    const orphanBookingId = new mongoose.Types.ObjectId();
    await ResourceReservation.create({
      bookingId: orphanBookingId,
      resourceId: 'CHESS-1',
      date: '2099-12-01',
      slotStart: 8 * 60
    });
    assert.equal(await releaseOrphanedReservations(), 1);
    assert.equal(await ResourceReservation.countDocuments({ bookingId: orphanBookingId }), 0);

    await AuditLog.create({
      role: 'admin',
      action: 'PATCH /api/admin/bookings/:id/status',
      statusCode: 200
    });
    assert.equal(await AuditLog.countDocuments({ role: 'admin' }), 1);

    const customerId = new mongoose.Types.ObjectId();
    const adminId = new mongoose.Types.ObjectId();
    const makeBooking = (activity, date, startTime, suffix, duration = 1) => createBooking({
      customerId,
      customerName: `Test ${suffix}`,
      mobile: '9876543210',
      activity,
      date,
      startTime,
      duration,
      players: 1
    });

    const badmintonRace = await Promise.allSettled([
      makeBooking('Badminton', '2099-12-01', '09:00', 'Badminton A'),
      makeBooking('Badminton', '2099-12-01', '09:00', 'Badminton B')
    ]);
    assert.equal(badmintonRace.filter((result) => result.status === 'fulfilled').length, 1);
    assert.equal(badmintonRace.filter((result) => result.status === 'rejected' && result.reason.code === 'SLOT_UNAVAILABLE').length, 1);
    await assert.rejects(createBooking({
      customerId,
      customerName: 'Invalid booking',
      mobile: '9876543210',
      activity: 'Badminton',
      date: '2099-12-01',
      startTime: '16:00',
      duration: 1,
      players: 0
    }));
    assert.equal(await ResourceReservation.countDocuments({
      resourceId: 'BADMINTON-1',
      date: '2099-12-01',
      slotStart: { $gte: 16 * 60, $lt: 17 * 60 }
    }), 0);

    const chessRace = await Promise.allSettled(Array.from({ length: 6 }, (_, index) =>
      makeBooking('Chess', '2099-12-01', '12:00', `Chess ${index}`)));
    assert.equal(chessRace.filter((result) => result.status === 'fulfilled').length, 5);
    assert.equal(chessRace.filter((result) => result.status === 'rejected' && result.reason.code === 'SLOT_UNAVAILABLE').length, 1);

    const cancelled = await makeBooking('Badminton', '2099-12-02', '09:00', 'Cancel');
    await assert.rejects(requestCancellation(cancelled.reference, new mongoose.Types.ObjectId().toString()), /Booking not found/);
    await requestCancellation(cancelled.reference, customerId.toString());
    await updateBookingStatus(cancelled._id, 'Cancelled');
    assert.equal((await makeBooking('Badminton', '2099-12-02', '09:00', 'After cancel')).status, 'Pending');

    const rescheduled = await makeBooking('Badminton', '2099-12-03', '10:00', 'Move');
    await requestReschedule(rescheduled.reference, customerId.toString(), { date: '2099-12-03', startTime: '11:00' });
    await assert.rejects(makeBooking('Badminton', '2099-12-03', '11:00', 'Occupied new slot'), { code: 'SLOT_UNAVAILABLE' });
    await assert.rejects(makeBooking('Badminton', '2099-12-03', '10:00', 'Original still secured'), { code: 'SLOT_UNAVAILABLE' });
    const approvedMove = await updateBookingStatus(rescheduled._id, 'Rescheduled');
    assert.equal(approvedMove.startTime, '11:00');
    assert.equal((await makeBooking('Badminton', '2099-12-03', '10:00', 'Freed old slot')).status, 'Pending');

    const paid = await makeBooking('Badminton', '2099-12-04', '09:00', 'Paid');
    await LoyaltyAccount.create({ customerId, badmintonCredits: 3, chessCredits: 0 });
    await recordPayment({ bookingId: paid._id, method: 'Cash', status: 'Paid', recordedBy: adminId });
    await updateBookingStatus(paid._id, 'Confirmed');
    await updateBookingStatus(paid._id, 'Completed');
    await updateBookingStatus(paid._id, 'Completed');
    assert.equal((await getLoyaltySummary(customerId)).badmintonCredits, 4);

    const freeBooking = await redeemReward({
      customerId,
      bookingPayload: {
        customerId,
        customerName: 'Test customer',
        mobile: '9876543210',
        activity: 'Badminton',
        date: '2099-12-05',
        startTime: '09:00',
        duration: 1,
        players: 1
      },
      createRewardBooking: (payload) => createBooking({ ...payload, isRewardBooking: true })
    });
    assert.equal(freeBooking.amount, 0);
    assert.equal(freeBooking.status, 'Confirmed');
    assert.ok(freeBooking.resourceId);
    assert.equal((await getLoyaltySummary(customerId)).badmintonCredits, 0);

    const upiBooking = await makeBooking('Chess', '2099-12-08', '10:00', 'UPI');
    await assert.rejects(recordPayment({
      bookingId: upiBooking._id,
      method: 'UPI',
      status: 'Paid',
      recordedBy: adminId
    }), /UPI transaction reference is required/);
    const upiPayment = await recordPayment({
      bookingId: upiBooking._id,
      method: 'UPI',
      status: 'Paid',
      transactionReference: 'UTR12345678',
      recordedBy: adminId
    });
    assert.equal(upiPayment.method, 'UPI');
    assert.equal(upiPayment.status, 'Paid');

    const concurrentlyMoved = await makeBooking('Chess', '2099-12-09', '08:00', 'Concurrent reschedule');
    const rescheduleResults = await Promise.allSettled([
      requestReschedule(concurrentlyMoved.reference, customerId.toString(), { startTime: '09:00' }),
      requestReschedule(concurrentlyMoved.reference, customerId.toString(), { startTime: '10:00' })
    ]);
    assert.equal(rescheduleResults.filter((result) => result.status === 'fulfilled').length, 1);
    assert.equal(rescheduleResults.filter((result) => result.status === 'rejected' && result.reason.code === 'BOOKING_BUSY').length, 1);

    const paymentRequired = await makeBooking('Badminton', '2099-12-06', '09:00', 'Unpaid');
    await updateBookingStatus(paymentRequired._id, 'Confirmed');
    await assert.rejects(updateBookingStatus(paymentRequired._id, 'Completed'), /paid payment record is required/);

    const activity = await PlayerActivity.create({
      hostCustomerId: customerId,
      activity: 'Chess',
      title: 'Concurrency test',
      date: '2099-12-07',
      time: '10:00',
      availableSlots: 1
    });
    const secondCustomer = new mongoose.Types.ObjectId();
    const joinResults = await Promise.all([
      invokeController(joinActivity, { params: { activityId: activity._id.toString() }, customer: { id: customerId.toString() } }),
      invokeController(joinActivity, { params: { activityId: activity._id.toString() }, customer: { id: secondCustomer.toString() } })
    ]);
    assert.equal(joinResults.filter((result) => result.statusCode === 200).length, 1);
    assert.equal(joinResults.filter((result) => result.statusCode === 409).length, 1);

    const waitlistReq = {
      body: { activity: 'Chess', date: '2099-12-07', time: '10:00' },
      customer: { id: customerId.toString() }
    };
    const waitlistResults = await Promise.all([
      invokeController(addWaitlist, waitlistReq),
      invokeController(addWaitlist, waitlistReq)
    ]);
    assert.equal(waitlistResults.filter((result) => result.statusCode === 201).length, 1);
    assert.equal(waitlistResults.filter((result) => result.statusCode === 409).length, 1);

    const pass = await ChessPass.create({
      customerId,
      customerName: 'Test customer',
      mobile: '9876543210',
      startDate: '2099-12-10',
      expiryDate: '2100-01-10'
    });
    assert.equal(pass.status, 'Pending');
    assert.equal((await ChessPass.find({ customerId })).length, 1);
  } finally {
    await mongoose.connection.dropDatabase();
    await mongoose.disconnect();
  }
});
