# PLAYHUB Project Audit

Audit performed against the existing project on 2026-11-06. Findings below are based on source inspection and the test/HTTP checks listed here; they are not a production penetration test.

## Verified implementation

| Area | Observed implementation | Evidence |
|---|---|---|
| Stack and layout | Vanilla HTML/CSS/JavaScript, Express, Mongoose, Node test runner, and Postman collection are present in the existing folders. | Source and package manifest inspection; local HTML links and JavaScript syntax checked. |
| Authentication | JWTs require an environment secret of at least 32 bytes; placeholder secrets are rejected. Admin and customer middleware enforce roles. Customer booking reads and mutations are scoped to the token customer ID. Passwords are bcrypt-hashed. Admin bootstrap uses environment credentials and has no public admin registration route. | Security tests and authenticated HTTP checks from the preceding audit. |
| Database | MongoDB is the persistence layer; database-required API routes fail with 503 while disconnected, and health performs a database ping. The configured local database URI passed a read-only ping. | HTTP test against a deliberately unreachable MongoDB endpoint returned `database: disconnected` and 503; configured URI ping succeeded. |
| Reservations | Unique reservation cells protect one badminton court and five chess tables. Failed booking creation attempts release their own partial reservations. Startup now releases reservations whose booking document is missing before migrating existing bookings. | MongoDB integration tests cover simultaneous limits, rollback, cancellation, rescheduling, and orphan cleanup. |
| Payments and credits | Admin records cash/UPI payments separately from booking status. Eligible completed paid bookings earn activity-specific credits; duplicate awards are prevented and four credits redeem a secured hour. | MongoDB integration tests. |
| Community and passes | MongoDB-backed activity joins, duplicate-resistant waitlist entries, and chess-pass requests/admin status updates exist. | MongoDB integration tests and source inspection. |
| HTTP hardening | Security response headers, API/auth/write request limits, and mutation audit records are now wired. | Unit tests for headers/rate limiting; audit-log persistence is covered by the MongoDB integration suite. |
| Postman/API docs | Local Postman collection and secret-free environment cover 36 requests; endpoint paths and methods match the mounted Express routes. API reference documents auth, payloads, and known limitations. | Collection/environment JSON, raw bodies, embedded scripts, protected-request headers, and route mappings validated. Postman Desktop Runner was not executed. |

## Security and operations notes

- The previous default JWT fallback is absent. `JWT_SECRET` is read only from the environment, and startup fails if it is missing, too short, or a known placeholder. The existing local `.env` was not changed or printed; its JWT secret and admin password did not meet the configured minimums during the prior local check. Replace them privately before starting the server.
- Rate limiting is in-process and keyed by the address Express observes. It is suitable as a basic single-process control, not a distributed limiter; production deployments with multiple workers or reverse proxies should use a shared limiter and configure proxy trust deliberately.
- The configured local MongoDB server reports standalone topology. Resource cells are arbitrated atomically by MongoDB's unique index; booking document creation and reservation acquisition use compensating rollback and startup orphan cleanup, not a multi-document transaction. A process crash in the middle can leave a temporary reservation until the next startup. For transaction-based all-or-nothing writes, deploy a replica set (or MongoDB Atlas) and add session-based transaction coverage before switching the write path.
- Audit entries contain the actor ID when authenticated, role, route template, method, response status, and timestamp. Request bodies, passwords, tokens, mobile numbers, and payment references are deliberately excluded. Audit-write failures are emitted as server errors in logs; audit records are not a substitute for backups.
- Production HTTPS termination, secure deployment secrets, backups/retention, and monitoring remain deployment responsibilities.

## Remaining product scope

These features are not established as complete by current source/tests and should not be presented as working:

- QR-specific booking flow, tournament/event registration, notifications, and staff management.
- Full admin calendar/customer/resource/settings/reporting modules and a detailed occupancy/revenue dashboard.
- Automated waitlist offers with customer acceptance and slot acquisition.
- Community host approval, validated court reservation linkage, participant experience matching, and cancelled-booking reconciliation.
- Chess-pass renewal/benefit enforcement and automatic expiry processing.
- A payment gateway; UPI is manual payment bookkeeping only.
- Loyalty credit reversal on refunds, a complete transaction ledger, and admin-adjustment workflows.
- Full browser-driven tests across all customer and admin forms and real Postman collection execution.

## Commands used for validation

```powershell
npm test
$env:PLAYHUB_TEST_MONGO_URI = 'mongodb://127.0.0.1:27017/playhub_test'
node --test tests/integration.test.js
Remove-Item Env:PLAYHUB_TEST_MONGO_URI
```

The Mongo integration test generates a separate timestamped database and drops only that generated database.
